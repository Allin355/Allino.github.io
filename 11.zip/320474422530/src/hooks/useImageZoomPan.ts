import { useState, useRef, useEffect, useCallback } from 'react';

interface ImageZoomPanHook {
  scale: number;
  position: { x: number; y: number };
  containerRef: React.RefObject<HTMLDivElement>;
  imageRef: React.RefObject<HTMLImageElement>;
  handleWheel: (e: React.WheelEvent) => void;
  handleDoubleClick: () => void;
  resetZoom: () => void;
  handleMouseDown: (e: React.MouseEvent) => void;
  handleMouseMove: (e: React.MouseEvent) => void;
  handleMouseUp: () => void;
  handleTouchStart: (e: React.TouchEvent) => void;
  handleTouchMove: (e: React.TouchEvent) => void;
}

export function useImageZoomPan(initialScale: number = 1): ImageZoomPanHook {
  const [scale, setScale] = useState(initialScale);
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [startX, setStartX] = useState(0);
  const [startY, setStartY] = useState(0);
  
  const containerRef = useRef<HTMLDivElement>(null);
  const imageRef = useRef<HTMLImageElement>(null);

  // 重置缩放和位置
  const resetZoom = useCallback(() => {
    setScale(initialScale);
    setPosition({ x: 0, y: 0 });
    setIsDragging(false);
  }, [initialScale]);

  // 处理鼠标双击重置
  const handleDoubleClick = useCallback(() => {
    resetZoom();
  }, [resetZoom]);

  // 处理滚轮缩放
  const handleWheel = useCallback((e: React.WheelEvent) => {
    e.preventDefault();
    
    if (!containerRef.current || !imageRef.current) return;
    
    // 获取容器和图片的尺寸和位置
    const containerRect = containerRef.current.getBoundingClientRect();
    const imageRect = imageRef.current.getBoundingClientRect();
    
    // 计算鼠标在容器中的相对位置（从中心点开始计算）
    const mouseX = e.clientX - containerRect.left - containerRect.width / 2;
    const mouseY = e.clientY - containerRect.top - containerRect.height / 2;
    
    // 计算鼠标在图片上的相对位置（考虑当前缩放和偏移）
    const relativeMouseX = mouseX - position.x;
    const relativeMouseY = mouseY - position.y;
    
    // 计算新的缩放比例
    const zoomFactor = e.deltaY > 0 ? 0.9 : 1.1;
    const newScale = Math.max(initialScale, Math.min(scale * zoomFactor, 5));
    
    // 计算新的位置，确保缩放中心点是鼠标位置
    const newX = mouseX - relativeMouseX * zoomFactor;
    const newY = mouseY - relativeMouseY * zoomFactor;
    
    setScale(newScale);
    setPosition({ x: newX, y: newY });
  }, [scale, position, initialScale]);

  // 处理鼠标按下事件
  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    if (scale <= initialScale) return; // 只有在放大后才能拖拽
    
    e.preventDefault();
    setIsDragging(true);
    setStartX(e.clientX - position.x);
    setStartY(e.clientY - position.y);
    
    // 添加样式以显示拖拽光标
    if (containerRef.current) {
      containerRef.current.style.cursor = 'grabbing';
    }
  }, [scale, position, initialScale]);

  // 处理鼠标移动事件
  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    if (!isDragging || scale <= initialScale) return;
    
    e.preventDefault();
    
    if (!containerRef.current || !imageRef.current) return;
    
    // 计算新的位置
    const newX = e.clientX - startX;
    const newY = e.clientY - startY;
    
    // 获取容器和图片信息
    const containerRect = containerRef.current.getBoundingClientRect();
    const imageRect = imageRef.current.getBoundingClientRect();
    
    // 计算图片实际大小（考虑缩放）
    const imageWidth = imageRect.width * scale;
    const imageHeight = imageRect.height * scale;
    
    // 添加边界限制，确保图片不会被拖拽出可视区域过多
    const maxX = (imageWidth - containerRect.width) / 2;
    const minX = -maxX;
    const maxY = (imageHeight - containerRect.height) / 2;
    const minY = -maxY;
    
    // 应用边界限制
    const clampedX = Math.max(minX, Math.min(maxX, newX));
    const clampedY = Math.max(minY, Math.min(maxY, newY));
    
    setPosition({ x: clampedX, y: clampedY });
  }, [isDragging, scale, startX, startY, initialScale]);

  // 处理鼠标释放事件
  const handleMouseUp = useCallback(() => {
    setIsDragging(false);
    
    // 恢复光标样式
    if (containerRef.current) {
      containerRef.current.style.cursor = 'grab';
    }
  }, []);

  // 处理触摸开始事件（支持移动设备）
  const handleTouchStart = useCallback((e: React.TouchEvent) => {
    if (scale <= initialScale || e.touches.length !== 1) return; // 只有单指触摸且放大后才能拖拽
    
    const touch = e.touches[0];
    setIsDragging(true);
    setStartX(touch.clientX - position.x);
    setStartY(touch.clientY - position.y);
  }, [scale, position, initialScale]);

  // 处理触摸移动事件（支持移动设备）
  const handleTouchMove = useCallback((e: React.TouchEvent) => {
    if (!isDragging || scale <= initialScale || e.touches.length !== 1) return;
    
    e.preventDefault();
    
    if (!containerRef.current || !imageRef.current) return;
    
    const touch = e.touches[0];
    
    // 计算新的位置
    const newX = touch.clientX - startX;
    const newY = touch.clientY - startY;
    
    // 获取容器和图片信息
    const containerRect = containerRef.current.getBoundingClientRect();
    const imageRect = imageRef.current.getBoundingClientRect();
    
    // 计算图片实际大小（考虑缩放）
    const imageWidth = imageRect.width * scale;
    const imageHeight = imageRect.height * scale;
    
    // 添加边界限制
    const maxX = (imageWidth - containerRect.width) / 2;
    const minX = -maxX;
    const maxY = (imageHeight - containerRect.height) / 2;
    const minY = -maxY;
    
    // 应用边界限制
    const clampedX = Math.max(minX, Math.min(maxX, newX));
    const clampedY = Math.max(minY, Math.min(maxY, newY));
    
    setPosition({ x: clampedX, y: clampedY });
  }, [isDragging, scale, startX, startY, initialScale]);

  // 当缩放比例回到初始值时，重置位置
  useEffect(() => {
    if (scale <= initialScale) {
      setPosition({ x: 0, y: 0 });
      setIsDragging(false);
    }
  }, [scale, initialScale]);

  // 清理拖拽状态
  useEffect(() => {
    const handleMouseUp = () => {
      setIsDragging(false);
      if (containerRef.current) {
        containerRef.current.style.cursor = 'grab';
      }
    };

    // 添加全局鼠标释放事件监听，确保在任何地方释放鼠标都能结束拖拽
    window.addEventListener('mouseup', handleMouseUp);
    window.addEventListener('touchend', handleMouseUp);

    return () => {
      window.removeEventListener('mouseup', handleMouseUp);
      window.removeEventListener('touchend', handleMouseUp);
    };
  }, []);

  return {
    scale,
    position,
    containerRef,
    imageRef,
    handleWheel,
    handleDoubleClick,
    resetZoom,
    handleMouseDown,
    handleMouseMove,
    handleMouseUp,
    handleTouchStart,
    handleTouchMove
  };
}
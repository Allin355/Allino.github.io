import { useEffect } from "react";
import { Routes, Route, useNavigate } from "react-router-dom";
import { AuthProvider } from "@/contexts/authContext.tsx";
import ProtectedRoute from "@/components/ProtectedRoute";
import Home from "@/pages/Home";
import ProjectDetail from "@/pages/ProjectDetail";
import AdminLogin from "@/pages/AdminLogin";
import AdminUpload from "@/pages/AdminUpload";
import AdminContent from "@/pages/AdminContent";
import AdminMessages from "@/pages/AdminMessages";

export default function App() {
  const navigate = useNavigate();
  
  // 添加触摸事件处理，防止移动端页面被拉动
  useEffect(() => {
    // 检测是否为移动设备
    const isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
    
    if (isMobile) {
      // 处理触摸开始事件
      const handleTouchStart = (e: TouchEvent) => {
        const startY = e.touches[0].clientY;
        
        // 处理触摸移动事件
        const handleTouchMove = (e: TouchEvent) => {
          const currentY = e.touches[0].clientY;
          const scrollTop = window.scrollY;
          
          // 判断是否在顶部且向下拉，或者在底部且向上拉
          if ((scrollTop === 0 && currentY > startY) || 
              (window.innerHeight + scrollTop >= document.body.offsetHeight && currentY < startY)) {
            e.preventDefault(); // 阻止默认行为，防止页面被拉动
          }
        };
        
        // 添加事件监听器
        window.addEventListener('touchmove', handleTouchMove, { passive: false });
        
        // 清理函数
        return () => {
          window.removeEventListener('touchmove', handleTouchMove);
        };
      };
      
      // 添加触摸开始事件监听
      window.addEventListener('touchstart', handleTouchStart);
      
      // 清理函数
      return () => {
        window.removeEventListener('touchstart', handleTouchStart);
      };
    }
  }, []);
  
  // 生产环境：添加性能监控
  useEffect(() => {
    if (import.meta.env.PROD) {
      // 这里可以添加实际的性能监控代码
      console.log('Production environment: Performance monitoring initialized');
    }
  }, []);

  // 添加键盘快捷键访问管理员登录页面
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // 使用 Ctrl+Alt+L 组合键访问管理员登录页面
      if (e.ctrlKey && e.altKey && e.key.toLowerCase() === 'l') {
        e.preventDefault();
        navigate('/admin/login');
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [navigate]);
  
  return (
    <AuthProvider>
      <Routes>
        {/* 公共路由 */}
        <Route path="/" element={<Home />} />
        <Route path="/project/:id" element={<ProjectDetail />} />
        {/* 确保即使没有id参数，也能匹配到项目页面路由 */}
        <Route path="/project/" element={<ProjectDetail />} />
        {/* 确保登录路由在最前面，避免被其他路由覆盖 */}
        <Route path="/admin/login" element={<AdminLogin />} />
        
        {/* 受保护的后台路由 */}
        <Route 
          path="/admin/upload" 
          element={
            <ProtectedRoute>
              <AdminUpload />
            </ProtectedRoute>
          } 
        />
        <Route 
          path="/admin/content" 
          element={
            <ProtectedRoute>
              <AdminContent />
            </ProtectedRoute>
          } 
        />
        
        {/* 管理员留言管理 */}
        <Route 
          path="/admin/messages" 
          element={
            <ProtectedRoute>
              <AdminMessages />
            </ProtectedRoute>
          } 
        />
        
        {/* 为后台添加根路由重定向 */}
        <Route path="/admin" element={<AdminLogin />} />
        
        {/* 确保所有admin子路由都能正确匹配 */}
        <Route path="/admin/*" element={<AdminLogin />} />
        
        {/* 404路由 */}
        <Route path="*" element={<Home />} />
      </Routes>
    </AuthProvider>
  );
}

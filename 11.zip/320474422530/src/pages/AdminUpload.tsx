import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { LogOut, Image, PlusCircle, X, Check, Home, Edit, Mail } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { useTheme } from '@/hooks/useTheme';
import { useAuth } from '@/contexts/authContext.tsx';
import UploadForm from '@/components/UploadForm';

// 定义项目类型
interface Project {
  id: number;
  title: string;
  category: string;
  imageUrl: string;
  description: string;
  client?: string;
  date?: string;
  tools?: string[];
  galleryImages?: string[];
}

// 管理员上传页面
const AdminUpload: React.FC = () => {
  const navigate = useNavigate();
  const { logout, isAuthenticated } = useAuth();
  const { isDark } = useTheme();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccessMessage, setShowSuccessMessage] = useState(false);
  const [projects, setProjects] = useState<Project[]>([]);

  // 检查认证状态
  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/admin/login');
    }
  }, [isAuthenticated, navigate]);

  // 加载已上传的项目
  useEffect(() => {
    const loadProjects = () => {
      try {
        const storedProjects = localStorage.getItem('projects');
        if (storedProjects) {
          setProjects(JSON.parse(storedProjects));
        }
      } catch (error) {
        console.error('加载项目失败:', error);
        toast('加载项目列表失败');
      }
    };

    loadProjects();
  }, [showSuccessMessage]); // 当成功上传新作品时重新加载

  // 处理登出
  const handleLogout = () => {
    logout();
    toast('已成功退出登录');
  };

  // 处理作品上传提交
  const handleFormSubmit = async (formData: FormData) => {
    if (isSubmitting) return;
    
    setIsSubmitting(true);
    
    try {
      // 模拟API请求延迟
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // 获取表单数据
      const title = formData.get('title') as string;
      const category = formData.get('category') as string;
      const description = formData.get('description') as string;
      const image = formData.get('image') as File;
      const client = formData.get('client') as string;
      const date = formData.get('date') as string;
      const toolsStr = formData.get('tools') as string;
      
      // 将文件转换为DataURL（实际项目中应上传到服务器）
      const imageUrl = await convertFileToDataURL(image);
      
      // 从localStorage获取现有作品数据
      const existingProjects = JSON.parse(localStorage.getItem('projects') || '[]');
      
      // 创建新项目对象
      const newProject: Project = {
        id: Date.now(), // 使用时间戳作为唯一ID
        title,
        category,
        imageUrl,
        description,
        client: client || undefined,
        date: date || undefined,
        tools: toolsStr ? toolsStr.split(',').map(tool => tool.trim()) : undefined,
        galleryImages: [imageUrl] // 简单地将主图也加入图库
      };
      
      // 添加新项目到现有数据
      const updatedProjects = [...existingProjects, newProject];
      
      // 保存更新后的数据到localStorage
      localStorage.setItem('projects', JSON.stringify(updatedProjects));
      
      // 显示成功消息
      setShowSuccessMessage(true);
      
      // 3秒后隐藏成功消息
      setTimeout(() => {
        setShowSuccessMessage(false);
      }, 3000);
      
      toast('作品上传成功！');
      
    } catch (error) {
      console.error('上传失败:', error);
      toast('上传失败，请重试');
    } finally {
      setIsSubmitting(false);
    }
  };

  // 将文件转换为DataURL
  const convertFileToDataURL = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => {
        resolve(reader.result as string);
      };
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  };

  return (
    <div className={`min-h-screen ${isDark ? 'bg-gray-950 text-white' : 'bg-gray-50 text-gray-900'} transition-colors duration-300`}>
      {/* 顶部导航 */}
      <motion.header
        className={`sticky top-0 z-40 w-full py-4 ${isDark ? 'bg-gray-900/90' : 'bg-white/90'} backdrop-blur-md shadow-sm`}
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="container mx-auto px-6 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Image size={24} className="text-indigo-500" />
            <h1 className="text-xl font-bold">作品管理后台</h1>
          </div>
          
          <div className="flex gap-3">
              <motion.button
                onClick={() => navigate('/admin/content')}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors ${
                  isDark ? 'bg-gray-800 hover:bg-gray-700' : 'bg-gray-100 hover:bg-gray-200'
                }`}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Edit size={16} />
                内容管理
              </motion.button>
              
              <motion.button
                onClick={() => navigate('/admin/messages')}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors ${
                  isDark ? 'bg-gray-800 hover:bg-gray-700' : 'bg-gray-100 hover:bg-gray-200'
                }`}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Mail size={16} />
                查看留言
              </motion.button>
              
              <motion.button
                onClick={() => navigate('/admin/messages')}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors ${
                  isDark ? 'bg-gray-800 hover:bg-gray-700' : 'bg-gray-100 hover:bg-gray-200'
                }`}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Mail size={16} />
                查看留言
              </motion.button>
             
             <motion.button
               onClick={() => navigate('/')}
               className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors ${
                 isDark ? 'bg-gray-800 hover:bg-gray-700' : 'bg-gray-100 hover:bg-gray-200'
               }`}
               whileHover={{ scale: 1.05 }}
               whileTap={{ scale: 0.95 }}
             >
               <Home size={16} />
               返回首页
             </motion.button>
            
            <motion.button
              onClick={handleLogout}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors ${
                isDark ? 'bg-gray-800 hover:bg-gray-700' : 'bg-gray-100 hover:bg-gray-200'
              }`}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <LogOut size={16} />
              退出登录
            </motion.button>
          </div>
        </div>
      </motion.header>

      <main className="container mx-auto px-6 py-10 max-w-4xl">
        {/* 成功上传消息 */}
        <AnimatePresence>
          {showSuccessMessage && (
            <motion.div
              className="mb-6 p-4 rounded-lg bg-green-50 text-green-800 dark:bg-green-900/30 dark:text-green-400 flex items-center gap-3"
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
            >
              <div className="p-1.5 rounded-full bg-green-100 text-green-600 dark:bg-green-800/50 dark:text-green-400">
                <Check size={18} />
              </div>
              <p className="font-medium">作品上传成功！</p>
            </motion.div>
          )}
        </AnimatePresence>

        {/* 上传表单卡片 */}
        <motion.div
          className={`p-8 rounded-xl shadow-lg ${isDark ? 'bg-gray-900' : 'bg-white'} border ${isDark ? 'border-gray-800' : 'border-gray-100'}`}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2 rounded-full bg-indigo-100 text-indigo-600 dark:bg-indigo-900/30 dark:text-indigo-400">
              <PlusCircle size={24} />
            </div>
            <h2 className="text-2xl font-bold">上传新作品</h2>
          </div>
          
          <UploadForm 
            onSubmit={handleFormSubmit} 
            isSubmitting={isSubmitting} 
          />
        </motion.div>

        {/* 已上传作品列表（可选） */}
        {projects.length > 0 && (
          <motion.div
            className="mt-12"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <h3 className="text-xl font-bold mb-6">已上传作品 ({projects.length})</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {projects.slice(-4).map((project) => (
                <motion.div
                  key={project.id}
                  className={`p-4 rounded-lg border ${isDark ? 'border-gray-800 bg-gray-900' : 'border-gray-200 bg-white'} flex items-center gap-4`}
                  whileHover={{ scale: 1.02 }}
                >
                  <div className="w-16 h-16 rounded overflow-hidden flex-shrink-0">
                    <img 
                      src={project.imageUrl} 
                      alt={project.title} 
                      className="w-full h-full object-cover"
                      loading="lazy"
                    />
                  </div>
                  <div className="flex-grow min-w-0">
                    <h4 className="font-medium text-sm truncate">{project.title}</h4>
                    <p className={`text-xs mt-1 ${isDark ? 'text-gray-500' : 'text-gray-400'}`}>
                      {new Date(project.id).toLocaleDateString()}
                    </p>
                  </div>
                  <motion.a
                    href={`/project/${project.id}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-xs px-3 py-1 rounded-full bg-indigo-100 text-indigo-600 dark:bg-indigo-900 dark:text-indigo-300"
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    查看
                  </motion.a>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}
      </main>
    </div>
  );
};

export default AdminUpload;
import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useParams, useNavigate, useLocation } from "react-router-dom";
import { ArrowLeft, ChevronLeft, ChevronRight } from "lucide-react";
import { useTheme } from "@/hooks/useTheme";
import { toast } from "sonner";
import { useImageZoomPan } from "@/hooks/useImageZoomPan";

// X图标组件定义
const X = ({ size = 24, ...props }: { size?: number, [key: string]: any }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    {...props}
  >
    <line x1="18" y1="6" x2="6" y2="18"></line>
    <line x1="6" y1="6" x2="18" y2="18"></line>
  </svg>
);

type ProjectCategory = "web" | "graphic" | "branding" | "ui" | "all";

interface Project {
  id: number;
  title: string;
  category: ProjectCategory;
  imageUrl: string;
  description: string;
  // 增加项目详情信息
  client?: string;
  date?: string;
  tools?: string[];
  challenges?: string;
  outcome?: string;
  // 多图支持
  galleryImages?: string[];
}

  // 从localStorage加载项目数据，如果没有则使用默认数据
  // 生产环境优化：添加错误处理和性能优化
  const getProjectsData = (): Project[] => {
  try {
    const storedProjects = localStorage.getItem('projects');
    if (storedProjects) {
      const parsedStoredProjects = JSON.parse(storedProjects);
      if (Array.isArray(parsedStoredProjects) && parsedStoredProjects.length > 0) {
        // 为存储的项目添加完整的详情信息
        return parsedStoredProjects.map((project: any) => ({
          ...project,
          // 确保所有必要的字段都存在
          galleryImages: project.galleryImages || [project.imageUrl],
          description: project.description || "这是一个精美的设计作品",
          client: project.client || undefined,
          date: project.date || undefined,
          tools: project.tools || undefined,
          challenges: project.challenges || undefined,
          outcome: project.outcome || undefined
        }));
      }
    }
  } catch (error) {
    console.error('加载存储的项目数据失败:', error);
  }
  
  // 默认项目数据
  return [
    {
      id: 1,
      title: "极简品牌重塑",
      category: "branding",
      imageUrl: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Minimalist%20branding%20design%20with%20clean%20lines%20and%20modern%20typography&sign=adbacac774537fac77a8483d1f4623e4",
      description: "为科技初创公司打造的简约品牌标识和视觉系统。这个项目专注于通过极简设计语言传达品牌核心价值，创造易于识别和记忆的视觉形象。设计过程包括品牌调研、标识设计、色彩系统开发以及应用规范制定。",
      client: "TechNova Inc.",
      date: "2023年10月",
      tools: ["Adobe Illustrator", "Figma", "Brand Guidelines Generator"],
      challenges: "在保持简约风格的同时确保品牌识别度和市场差异化",
      outcome: "成功为客户创建了全新的品牌形象，提升了品牌认知度和市场竞争力",
      galleryImages: [
        "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Minimalist%20branding%20design%20with%20clean%20lines%20and%20modern%20typography&sign=adbacac774537fac77a8483d1f4623e4",
        "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Brand%20identity%20design%20with%20logo%20applications&sign=27d58258b5c7f9012256a1cd2c9e9c0d",
        "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Minimalist%20business%20card%20design&sign=dff7cd0a240feab63d19e020fa400de7"
      ]
    },
    {
      id: 2,
      title: "电商网站设计",
      category: "web",
      imageUrl: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=E-commerce%20website%20design%20with%20minimalist%20interface%20and%20elegant%20product%20displays&sign=b3e7c80173126222ea4eeb07fd4de9e1",
      description: "注重用户体验的电商平台界面设计。该设计以简洁明了的导航结构和优雅的产品展示为核心，通过优化购物流程和交互设计，提升用户转化率。项目包括用户研究、竞品分析、信息架构设计、界面原型和视觉设计。",
      client: "Luxe Fashion Store",
      date: "2023年8月",
      tools: ["Figma", "Adobe XD", "InVision"],
      challenges: "设计直观的购物流程，减少购物车放弃率",
      outcome: "重新设计后，客户报告转化率提升了35%，购物车放弃率下降了22%",
      galleryImages: [
        "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=E-commerce%20website%20design%20with%20minimalist%20interface%20and%20elegant%20product%20displays&sign=b3e7c80173126222ea4eeb07fd4de9e1",
        "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Product%20detail%20page%20design%20for%20e-commerce%20site&sign=18f13bc79bc149fa14c321e50d0e8788",
        "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Checkout%20process%20UI%20design&sign=e447694ef2dc27897ffb000072f77d3e"
      ]
    },
    {
      id: 3,
      title: "企业年报设计",
      category: "graphic",
      imageUrl: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Corporate%20annual%20report%20design%20with%20minimalist%20layout%20and%20data%20visualization&sign=c2014615f11106528b28297773e316bc",
      description: "融合数据可视化的企业年报设计。这份年报通过创新的数据可视化方式和精心编排的内容结构，使复杂的财务数据和业务信息变得清晰易懂。设计遵循品牌视觉语言，同时注入新的创意元素，提升年报的可读性和视觉吸引力。",
      client: "Global Finance Group",
      date: "2023年3月",
      tools: ["Adobe InDesign", "Adobe Illustrator", "Tableau"],
      challenges: "将复杂的财务数据转化为直观易懂的可视化图表",
      outcome: "年报获得了行业设计奖项，并受到投资者和股东的高度评价",
      galleryImages: ["https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Corporate%20annual%20report%20design%20with%20minimalist%20layout%20and%20data%20visualization&sign=c2014615f11106528b28297773e316bc",
        "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Financial%20data%20visualization%20design&sign=4aa7b5ae7d45710408b559024b657321","https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Annual%20report%20infographic%20design&sign=cac10d08f4e94747fe0b2eb11bea9938"
      ]
    },
    {
      id: 4,
      title: "餐厅品牌形象",
      category: "branding",
      imageUrl: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Restaurant%20branding%20identity%20with%20elegant%20logo%20and%20menu%20design&sign=bd510eadadef27151e6660677e21fd01",
      description: "为高端餐厅创建的完整品牌视觉系统。从标志设计到菜单、餐具、空间设计等各个环节，打造出统一而独特的品牌体验。设计灵感来源于餐厅的烹饪理念和文化背景，通过精致的细节和质感传达高端餐饮体验。",
      client: "Bistro Elegance",
      date: "2023年5月",
      tools: ["Adobe Illustrator", "Photoshop", "3D Max"],
      challenges: "创建能够反映餐厅高端定位和独特烹饪风格的视觉形象",
      outcome: "品牌重塑后，餐厅客流量增加了45%，客户满意度显著提升",
      galleryImages: [
        "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Restaurant%20branding%20identity%20with%20elegant%20logo%20and%20menu%20design&sign=bd510eadadef27151e6660677e21fd01",
        "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Fine%20dining%20menu%20design&sign=e404a5eee26555e50cac9195a99cdfd3",
        "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Restaurant%20interior%20branding%20design&sign=c92cd7bd31a1e14f161791c1ab5967b3"
      ]
    },
    {
      id: 5,
      title: "移动应用界面",
      category: "ui",
      imageUrl: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Mobile%20app%20interface%20design%20with%20clean%20UI%20and%20intuitive%20UX&sign=9031c85ddf5ded48818872a4e7d0b209",
      description: "专注于用户体验的移动应用界面设计。这个项目强调简洁直观的交互设计和视觉层次，通过用户研究和测试不断优化界面流程，确保用户能够轻松完成核心任务。设计风格现代简约，同时保持品牌识别度。",
      client: "HealthPlus App",
      date: "2023年7月",
      tools: ["Figma", "Sketch", "Principle"],
      challenges: "设计易于使用的健康追踪界面，适合不同年龄段的用户",
      outcome: "应用上线后获得了10万+下载量，用户评分4.8/5",
      galleryImages: [
        "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Mobile%20app%20interface%20design%20with%20clean%20UI%20and%20intuitive%20UX&sign=9031c85ddf5ded48818872a4e7d0b209",
        "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Health%20tracking%20dashboard%20UI&sign=6814b8f50b8c8bd1b17d1990b951c575",
        "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Mobile%20app%20profile%20page%20design&sign=67cdd5c41bb744d4e6a8c2126887e6a5"
      ]
    },
    {
      id: 6,
      title: "产品包装设计",
      category: "graphic",
      imageUrl: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Product%20packaging%20design%20with%20minimalist%20aesthetics%20and%20sustainable%20materials&sign=fe248308c31747eb5c0a6e091f216353",
      description: "结合环保理念的极简产品包装设计。这个包装设计不仅注重美观和品牌传达，还考虑了环保因素，采用可回收材料和精简的结构设计。通过巧妙的材质组合和工艺处理，在减少环境影响的同时，提升产品的高端感和用户体验。",
      client: "EcoLiving Products",
      date: "2023年9月",
      tools: ["Adobe Illustrator", "ArtiosCAD", "Photoshop"],
      challenges: "在环保材料限制下创造出具有高端感的包装设计",
      outcome: "包装设计获得了可持续设计奖，并帮助产品在零售店中脱颖而出",
      galleryImages: [
        "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Product%20packaging%20design%20with%20minimalist%20aesthetics%20and%20sustainable%20materials&sign=fe248308c31747eb5c0a6e091f216353","https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Eco-friendly%20packaging%20design%20mockup&sign=d82773c1388c800c69cd0a7b8344960f",
        "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Sustainable%20product%20packaging%20on%20shelf&sign=11fe483ac3b1a655a034848efc6d50be"
      ]
    },
    {
      id: 7,
      title: "金融App设计",
      category: "ui",imageUrl: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Financial%20app%20UI%20design%20with%20clean%20interface%20and%20data%20visualization&sign=dbe03224a82295b5f04b8b161ccc4c88",
      description: "专注于数据可视化和用户体验的金融应用界面设计。这个金融App设计通过直观的数据展示和清晰的信息架构，帮助用户轻松理解和管理个人财务。界面设计简约而不简单，注重细节处理和交互反馈，提升用户信任感和使用体验。",
      client: "FinSmart Solutions",
      date: "2023年6月",
      tools: ["Figma", "Adobe XD", "Chart.js"],
      challenges: "设计直观的金融数据可视化，同时确保信息的准确性和安全性",
      outcome: "应用推出后用户参与度提升了60%，用户停留时间延长了45%",
      galleryImages: [
        "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Financial%20app%20UI%20design%20with%20clean%20interface%20and%20data%20visualization&sign=dbe03224a82295b5f04b8b161ccc4c88",
        "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Financial%20dashboard%20UI%20with%20charts&sign=af308fc0ba020cb49f99bef3dace70c8",
        "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Investment%20portfolio%20tracking%20UI&sign=e964703b9f6561b72b40fb6bf5d3a6e3"
      ]
    },
    {
      id: 8,
      title: "Oura健康品牌官网",
      category: "web",
      imageUrl: "https://lf-code-agent.coze.cn/obj/x-ai-cn/320474422530/attachment/ouraring.com_about-us_20251225153228.png",
      description: "Oura健康品牌官网的关于我们页面，展示了品牌使命、价值观和企业数据。页面采用简约优雅的设计风格，通过精美的排版和高质量的图像，传达了品牌致力于让健康成为日常实践的理念。设计特点包括舒适的阅读体验、清晰的信息层次和精美的视觉元素。",
      client: "Oura Health",
      date: "2023年11月",
      tools: ["Figma", "Webflow", "Photoshop"],
      challenges: "创建能够反映品牌高端健康理念的现代网站设计",
      outcome: "网站上线后获得了设计界的广泛认可，访问量在首月增长了200%",
      galleryImages: [
        "https://lf-code-agent.coze.cn/obj/x-ai-cn/320474422530/attachment/ouraring.com_about-us_20251225153228.png",
        "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Health%20brand%20website%20homepage%20design&sign=c7a23ecc4475b43b79791c001bd47a45",
        "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Product%20page%20design%20for%20health%20wearable&sign=05bef06c25917ac61cab87ff4eec50b8"
      ]
    }
  ];
};

// 初始加载项目数据
const projectsData = getProjectsData();

export default function ProjectDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { isDark } = useTheme();
  const [project, setProject] = useState<Project | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [isImageModalOpen, setIsImageModalOpen] = useState(false);
  
   // 使用图片缩放Hook
  const {
    scale,
    position,
    containerRef,
    imageRef,
    handleWheel,
    handleDoubleClick,
    resetZoom,
    handleMouseDown,
    handleMouseMove,
    handleMouseUp,
    handleTouchStart,
    handleTouchMove
  } = useImageZoomPan();

  // 增强刷新处理逻辑，确保刷新页面后保持在当前详情页
  useEffect(() => {
    // 页面加载时，如果URL包含项目ID，则确保保持在当前页面
    // React Router通常会自动处理URL保持，但添加此逻辑以增强可靠性
    const handlePageLoad = () => {
      if (window.location.pathname.startsWith('/project/')) {
        // 可以在这里添加额外的逻辑，比如记录访问的项目ID等
      }
    };

    handlePageLoad();// 保存当前页面状态到localStorage，增强页面刷新后的恢复能力
    const savePageState = () => {
      if (id) {
        localStorage.setItem('lastVisitedProject', id);
      }
    };
    
    // 监听页面刷新事件
    const handleBeforeUnload = () => {
      savePageState();
    };
    
    window.addEventListener('beforeunload', handleBeforeUnload);
    
    return () => {
      window.removeEventListener('beforeunload', handleBeforeUnload);
    };
  }, [id]);

  useEffect(() => {
    // 增强的项目查找逻辑，确保即使在刷新页面后也能正确加载项目
    const findProject = () => {
      if (!id) {
        setProject(null);
        setIsLoading(false);
        return;
      }
      
      // 尝试将id转换为数字，处理可能的类型转换异常
      let projectId: number;
      try {
        projectId = parseInt(id, 10);
      } catch (error) {
        console.error('无效的项目ID:', id);
        setProject(null);
        setIsLoading(false);
        return;
      }
      
      // 查找对应的项目
      const foundProject = projectsData.find(p => p.id === projectId);
      
      // 如果找不到项目，仍然显示当前页面但展示错误信息
      setProject(foundProject || null);
      setIsLoading(false);
      setCurrentImageIndex(0);
    };

    findProject();

    // 添加返回键监听
    const handleBackPress = (e: KeyboardEvent) => {
      if (e.key === "Backspace") {
        navigate(-1);
      }
    };

    window.addEventListener("keydown", handleBackPress);
    return () => window.removeEventListener("keydown", handleBackPress);
  }, [id, navigate]);

  // 处理返回按钮点击
  const handleBack = () => {
    // 设置返回标记，确保首页知道是从作品页返回的
    localStorage.setItem('fromProjectDetail', 'true');
    navigate(-1);
  };
  
  // 处理模态框打开
  const openImageModal = () => {
    setIsImageModalOpen(true);
    document.body.style.overflow = 'hidden'; // 防止背景滚动
  };
  
  // 处理模态框关闭
  const closeImageModal = () => {
    setIsImageModalOpen(false);
    document.body.style.overflow = 'auto'; // 恢复背景滚动
    // 关闭时重置缩放状态
    resetZoom();
  };

  // 获取分类显示名称
  const getCategoryName = (category: ProjectCategory) => {
    switch (category) {
      case "web": return "网页设计";
      case "graphic": return "平面设计";
      case "branding": return "品牌设计";
      case "ui": return "UI设计";
      default: return "全部";
    }
  };

  // 获取分类对应的样式类
  const getCategoryClass = (category: ProjectCategory) => {
    switch (category) {
      case "web": return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200";
      case "graphic": return "bg-pink-100 text-pink-800 dark:bg-pink-900 dark:text-pink-200";
      case "branding": return "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200";
      case "ui": return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200";
      default: return "";
    }
  };

  // 图片导航
  const goToNextImage = () => {
    if (!project?.galleryImages) return;
    setCurrentImageIndex((prev) => 
      prev === project.galleryImages.length - 1 ? 0 : prev + 1
    );
    // 切换图片时重置缩放状态
    resetZoom();
  };

  const goToPrevImage = () => {
    if (!project?.galleryImages) return;
    setCurrentImageIndex((prev) => 
      prev === 0 ? project.galleryImages.length - 1 : prev - 1
    );
    // 切换图片时重置缩放状态
    resetZoom();
  };

  // 处理键盘事件
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // ESC键关闭模态框
      if (e.key === 'Escape' && isImageModalOpen) {
        closeImageModal();
      }
      // 左右箭头键切换图片
      if (project?.galleryImages && project.galleryImages.length > 1) {
        if (e.key === 'ArrowLeft') {
          e.preventDefault();
          goToPrevImage();
        } else if (e.key === 'ArrowRight') {
          e.preventDefault();
          goToNextImage();
        }
      }
    };
    
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isImageModalOpen, project?.galleryImages, currentImageIndex]);

  // 骨架屏加载状态
  if (isLoading) {
    return (
      <div className={`min-h-screen ${isDark ? "bg-gray-950 text-white" : "bg-white text-gray-900"}`}>
        <div className="container mx-auto px-6 py-20 flex justify-center items-center h-full">
          <div className="flex flex-col items-center">
            <motion.div 
              animate={{ rotate: 360 }} 
              transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
              className="w-12 h-12 border-4 border-t-indigo-500 border-r-transparent border-b-transparent border-l-transparent rounded-full"
            />
            <p className="mt-4 text-lg">加载中...</p>
          </div>
        </div>
      </div>
    );
  }

  // 项目不存在状态 - 即使项目不存在，也保持在当前页面并显示友好提示
  if (!project && !isLoading) {
    return (
      <div className={`min-h-screen ${isDark ? "bg-gray-950 text-white" : "bg-white text-gray-900"}`}>
        {/* 返回按钮 - 即使项目不存在也显示返回按钮 */}
        <motion.button
          onClick={handleBack}
          className={`fixed top-6 left-6 p-3 rounded-full z-50 ${isDark ? "bg-gray-900 hover:bg-gray-800" : "bg-white hover:bg-gray-100 shadow-md"} transition-colors`}
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.3 }}
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
        >
          <ArrowLeft size={20} />
        </motion.button>
        
        <div className="container mx-auto px-6 py-20 flex justify-center items-center h-full">
          <div className="text-center max-w-md">
            <h2 className="text-3xl font-bold mb-4">项目不存在</h2>
            <p className="mb-6">抱歉，您访问的项目不存在或已被删除。</p>
            <motion.button
              onClick={handleBack}
              className="px-6 py-3 bg-indigo-500 text-white rounded-md font-medium hover:bg-indigo-600 transition-colors"
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.98 }}
            >
              返回上一页
            </motion.button>
          </div>
        </div>
      </div>
    );
  }

  // 获取当前要显示的图片
  const currentImage = project.galleryImages?.[currentImageIndex] || project.imageUrl;

  return (
    <div className={`min-h-screen ${isDark ? "bg-gray-950 text-white" : "bg-white text-gray-900"} transition-colors duration-300`}>
      {/* 返回按钮 */}
      <motion.button
        onClick={handleBack}
        className={`fixed top-6 left-6 p-3 rounded-full z-50 ${isDark ? "bg-gray-900 hover:bg-gray-800" : "bg-white hover:bg-gray-100 shadow-md"} transition-colors`}
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.3 }}
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
      >
        <ArrowLeft size={20} />
      </motion.button>

      <main className="container mx-auto px-4 py-16 md:py-24">
        <AnimatePresence>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-5xl mx-auto"
          >
            {/* 项目分类标签 */}
            <div className="mb-6 flex items-center">
              <span
                className={`inline-block px-3 py-1 text-xs font-medium rounded-full ${getCategoryClass(project.category)}`}
              >
                {getCategoryName(project.category)}
              </span>
            </div>

            {/* 项目标题 */}
            <motion.h1
              className="text-3xl md:text-4xl font-bold mb-6"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              {project.title}
            </motion.h1>

            {/* 项目元信息 */}
            {project.client && (
              <motion.div className={`grid grid-cols-1 md:grid-cols-3 gap-6 mb-10 p-4 rounded-lg ${isDark ? "bg-gray-900" : "bg-gray-50"}`}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.3 }}
              >
                {project.client && (
                  <div>
                    <h3 className={`text-sm font-medium mb-1 ${isDark ? "text-gray-400" : "text-gray-500"}`}>客户</h3>
                    <p className="font-medium">{project.client}</p>
                  </div>
                )}
                {project.date && (
                  <div>
                    <h3 className={`text-sm font-medium mb-1 ${isDark ? "text-gray-400" : "text-gray-500"}`}>日期</h3>
                    <p className="font-medium">{project.date}</p>
                  </div>
                )}
                {project.tools && project.tools.length > 0 && (
                  <div>
                    <h3 className={`text-sm font-medium mb-1 ${isDark ? "text-gray-400" : "text-gray-500"}`}>工具</h3>
                    <p className="font-medium">{project.tools.join(", ")}</p>
                  </div>
                )}
              </motion.div>
            )}

            {/* 项目图片展示区 */}
            <motion.div
              className="mb-12 relative"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
            >
                <div 
                 className={`overflow-hidden rounded-xl shadow-2xl cursor-pointer`}
                 onClick={openImageModal}
               >
                  <motion.img
                   src={currentImage}
                   alt={`${project.title} - 图片 ${currentImageIndex + 1}`}
                   className="w-full h-auto object-cover"
                   loading="eager"
                   style={{ 
                     maxHeight: '900px'
                   }}
                 />
              </div>
              
              {/* 多图导航控制按钮 */}
              {project.galleryImages && project.galleryImages.length > 1 && (
                <>
                  <motion.button
                    className={`absolute left-4 top-1/2 -translate-y-1/2 p-2 rounded-full ${isDark ? "bg-gray-900/80 hover:bg-gray-800" : "bg-white/80 hover:bg-white shadow-lg"} backdrop-blur-sm transition-colors`}
                    onClick={(e) => {
                      e.stopPropagation();
                      goToPrevImage();
                    }}
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                  >
                    <ChevronLeft size={24} />
                  </motion.button>
                  
                  <motion.button
                    className={`absolute right-4 top-1/2 -translate-y-1/2 p-2 rounded-full ${isDark ? "bg-gray-900/80 hover:bg-gray-800" : "bg-white/80 hover:bg-white shadow-lg"} backdrop-blur-sm transition-colors`}
                    onClick={(e) => {
                      e.stopPropagation();
                      goToNextImage();
                    }}
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                  >
                    <ChevronRight size={24} />
                  </motion.button>
                  
                  {/* 图片计数器 */}
                  <div className={`absolute bottom-4 left-1/2 -translate-x-1/2 px-4 py-2 rounded-full ${isDark ? "bg-gray-900/80" : "bg-white/80"} backdrop-blur-sm text-sm font-medium`}>
                    {currentImageIndex + 1} / {project.galleryImages.length}
                  </div>
                </>
              )}
              
              {/* 放大查看提示 */}
              <motion.div 
                className={`absolute top-4 right-4 px-3 py-1 rounded-full bg-black/70 text-white text-xs font-medium`}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.5, delay: 1 }}
              >
                点击查看大图
              </motion.div>
            </motion.div>

            {/* 项目描述 */}
            <motion.div
              className={`mb-12 p-6 rounded-lg ${isDark ? "bg-gray-900" : "bg-gray-50"}`}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.6 }}
            >
              <h2 className="text-xl font-semibold mb-4">项目描述</h2>
              <p className={`text-lg leading-relaxed ${isDark ? "text-gray-300" : "text-gray-700"}`}>
                {project.description}
              </p>
            </motion.div>

          </motion.div>
        </AnimatePresence>
      </main>

      {/* 图片预览模态框 */}
      <AnimatePresence>
        {isImageModalOpen && (
          <motion.div 
            className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/90"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={closeImageModal}
          >
            <motion.button
              className="absolute top-6 right-6 p-3 rounded-full bg-black/50 text-white hover:bg-black/80 transition-colors"
              onClick={closeImageModal}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            >
              <X size={24} />
            </motion.button>
            
             {/* 操作控制提示 */}
             <motion.div 
               className="absolute bottom-6 left-6 px-4 py-2 rounded-full bg-black/70 text-white text-sm font-medium flex items-center gap-2"
               initial={{ opacity: 0 }}
               animate={{ opacity: 1 }}
               transition={{ duration: 0.5, delay: 0.5 }}
             >
               <span>鼠标滚轮缩放</span>
               <span className="text-xs opacity-70">|</span>
               <span>拖拽移动</span>
               <span className="text-xs opacity-70">|</span>
               <span>双击重置</span>
             </motion.div>

                <div className="relative w-full max-w-7xl h-full flex items-center justify-center">
                   {project.galleryImages && project.galleryImages.length > 1 && (
                     <>
                       <motion.button
                         className="absolute left-4 top-1/2 -translate-y-1/2 p-3 rounded-full bg-black/50 text-white hover:bg-black/80 transition-colors z-10"
                         onClick={(e) => {
                           e.stopPropagation();
                           goToPrevImage();
                         }}
                         whileHover={{ scale: 1.1 }}
                         whileTap={{ scale: 0.9 }}
                       >
                         <ChevronLeft size={32} />
                       </motion.button>
                       
                       <motion.button
                         className="absolute right-4 top-1/2 -translate-y-1/2 p-3 rounded-full bg-black/50 text-white hover:bg-black/80 transition-colors z-10"
                         onClick={(e) => {
                           e.stopPropagation();
                           goToNextImage();
                         }}
                         whileHover={{ scale: 1.1 }}
                         whileTap={{ scale: 0.9 }}
                       >
                         <ChevronRight size={32} />
                       </motion.button>
                       
                       {/* 图片计数器 */}
                       <div className="absolute bottom-4 left-1/2 -translate-x-1/2 px-4 py-2 rounded-full bg-black/70 text-white text-sm font-medium">
                         {currentImageIndex + 1} / {project.galleryImages.length}
                       </div>
                     </>
                   )}

                     {/* 可缩放和拖拽的图片容器 - 完整展示图片 */}
                    <div 
                      className="relative w-full h-full flex items-center justify-center"
                      ref={containerRef}
                      onWheel={handleWheel}
                      onDoubleClick={handleDoubleClick}
                      onMouseDown={handleMouseDown}
                      onMouseMove={handleMouseMove}
                      onMouseUp={handleMouseUp}
                      onMouseLeave={handleMouseUp} // 鼠标离开容器时也结束拖拽
                      onTouchStart={handleTouchStart}
                      onTouchMove={handleTouchMove}
                      onClick={(e) => e.stopPropagation()} // 防止点击图片容器时关闭模态框
                      style={{ 
                        minHeight: '400px', 
                        userSelect: 'none',
                        cursor: scale > 1 ? 'grab' : 'default' // 只有在放大后才显示拖拽光标
                      }}
                    >
                       <motion.img
                        key={currentImage}
                        src={currentImage}
                        alt={`${project.title} - 预览图片 ${currentImageIndex + 1}`}
                        ref={imageRef}
                        className="max-w-full max-h-[90vh] object-contain"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ duration: 0.3 }}
                        loading="eager"
                        style={{
                          transform: `scale(${scale}) translate(${position.x}px, ${position.y}px)`,
                          transition: 'transform 0.1s ease-out',
                          willChange: 'transform',
                          userDrag: 'none' // 防止浏览器默认的拖拽行为
                        }}
                      />
                    </div>
                </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
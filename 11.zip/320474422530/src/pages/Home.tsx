import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Menu, X, ArrowRight, Instagram, Linkedin, Mail, ExternalLink } from "lucide-react";
import { useTheme } from "@/hooks/useTheme";
import { toast } from "sonner";
type ProjectCategory = "web" | "graphic" | "branding" | "ui" | "all";

// 定义网站内容的类型
interface SiteContent {
  // 网站基本信息
  siteInfo: {
    title: string;
    description: string;
  };
  
  // 英雄区内容
  heroSection: {
    heading: string;
    subheading: string;
    buttonText: string;
  };
  
  // 关于设计师板块
  aboutSection: {
    title: string;
    subtitle: string;
    designerName: string;
    bio1: string;
    bio2: string;
    experience: string;
    skills: string[];
    tools: string[];
    imageUrl: string;
  };
  
  // 联系部分
  contactSection: {
    title: string;
    subtitle: string;
    phone: string;
    wechat: string;
    email: string;
    responseTimeText: string;
  };
  
  // 页脚内容
  footerSection: {
    copyrightText: string;
    footerDescription: string;
  };
}

// 默认网站内容
const defaultContent: SiteContent = {
  siteInfo: {
    title: "Alex Design Studio | 简约高级的设计作品",
    description: "专注于创造简约而富有意义的设计作品，致力于将复杂的问题转化为直观优雅的解决方案。"
  },
  
  heroSection: {
    heading: "用设计解决问题，以创意创造价值",
    subheading: "我是Alex，一位专注于创造简约而富有意义的设计作品的设计师，致力于将复杂的问题转化为直观优雅的解决方案。",
    buttonText: "查看我的作品"
  },
  
  aboutSection: {
    title: "关于设计师",
    subtitle: "专注于创造简约而富有意义的设计作品，致力于将复杂的问题转化为直观优雅的解决方案",
    designerName: "Alex Chen",
    bio1: "你好，我是Alex，一位充满热情的设计师，专注于品牌设计、网页设计和用户界面设计。我相信设计不仅仅是表面的美观，更是解决问题和创造有意义体验的强大工具。",
    bio2: "我的设计理念是将复杂的问题简化，通过清晰的视觉语言和直观的用户体验，帮助品牌与目标受众建立真实的连接。每个项目对我来说都是一次新的探索和创造机会。",
    experience: "10+",
    skills: ["品牌识别设计", "网页与交互设计", "用户界面设计", "响应式设计"],
    tools: ["Adobe Creative Suite", "Figma", "Sketch", "Webflow"],
    imageUrl: "https://space.coze.cn/api/coze_space/gen_image?image_size=portrait_4_3&prompt=Portrait%20of%20a%20modern%20graphic%20designer%20working%20in%20a%20studio&sign=4f2f6f7f6bfc07238629c6615ea5a092"
  },
  
  contactSection: {
    title: "联系我",
    subtitle: "对我的作品感兴趣或者有合作意向？请随时联系我，我很期待与您交流",
    phone: "13553551446",
    wechat: "two193667280",
    email: "2331748170@qq.com",
    responseTimeText: "我通常会在24小时内回复您的邮件和消息"
  },
  
  footerSection: {
    copyrightText: `© ${new Date().getFullYear()} Alex Design Studio. 保留所有权利。`,
    footerDescription: "创造简约而有意义的设计"
  }
};

interface Project {
    id: number;
    title: string;
    category: ProjectCategory;
    imageUrl: string;
    description: string;
}

const getProjectsData = (): Project[] => {
    try {
        const storedProjects = localStorage.getItem("projects");

        if (storedProjects) {
            const parsedStoredProjects = JSON.parse(storedProjects);

            if (Array.isArray(parsedStoredProjects) && parsedStoredProjects.length > 0) {
                return parsedStoredProjects;
            }
        }
    } catch (error) {
        console.error("加载存储的项目数据失败:", error);
    }

    return [{
        id: 1,
        title: "极简品牌重塑",
        category: "branding",
        imageUrl: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Minimalist%20branding%20design%20with%20clean%20lines%20and%20modern%20typography&sign=adbacac774537fac77a8483d1f4623e4",
        description: "为科技初创公司打造的简约品牌标识和视觉系统"
    }, {
        id: 2,
        title: "电商网站设计",
        category: "web",
        imageUrl: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=E-commerce%20website%20design%20with%20minimalist%20interface%20and%20elegant%20product%20displays&sign=b3e7c80173126222ea4eeb07fd4de9e1",
        description: "注重用户体验的电商平台界面设计"
    }, {
        id: 3,
        title: "企业年报设计",
        category: "graphic",
        imageUrl: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Corporate%20annual%20report%20design%20with%20minimalist%20layout%20and%20data%20visualization&sign=c2014615f11106528b28297773e316bc",
        description: "融合数据可视化的企业年报设计"
    }, {
        id: 4,
        title: "餐厅品牌形象",
        category: "branding",
        imageUrl: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Restaurant%20branding%20identity%20with%20elegant%20logo%20and%20menu%20design&sign=bd510eadadef27151e6660677e21fd01",
        description: "为高端餐厅创建的完整品牌视觉系统"
    }, {
        id: 5,
        title: "移动应用界面",
        category: "ui",
        imageUrl: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Mobile%20app%20interface%20design%20with%20clean%20UI%20and%20intuitive%20UX&sign=9031c85ddf5ded48818872a4e7d0b209",
        description: "专注于用户体验的移动应用界面设计"
    }, {
        id: 6,
        title: "产品包装设计",
        category: "graphic",
        imageUrl: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Product%20packaging%20design%20with%20minimalist%20aesthetics%20and%20sustainable%20materials&sign=fe248308c31747eb5c0a6e091f216353",
        description: "结合环保理念的极简产品包装设计"
    }, {
        id: 7,
        title: "金融App设计",
        category: "ui",
        imageUrl: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Financial%20app%20UI%20design%20with%20clean%20interface%20and%20data%20visualization&sign=dbe03224a82295b5f04b8b161ccc4c88",
        description: "专注于数据可视化和用户体验的金融应用界面设计"
    }, {
        id: 8,
        title: "Oura健康品牌官网",
        category: "web",
        imageUrl: "https://lf-code-agent.coze.cn/obj/x-ai-cn/320474422530/attachment/ouraring.com_about-us_20251225153228.png",
        description: "Oura健康品牌官网的关于我们页面，展示了品牌使命和价值观"
    }];
};

const projectsData = getProjectsData();

interface NavLink {
  id: number;
  label: string;
  href: string;
}

export default function Home() {
  const {
    theme,
    toggleTheme,
    isDark
  } = useTheme();
  
  // 加载网站内容
  const [content, setContent] = useState<SiteContent>(defaultContent);
  
  useEffect(() => {
    const fromProjectDetail = localStorage.getItem("fromProjectDetail");

    if (fromProjectDetail === "true") {
      localStorage.removeItem("fromProjectDetail");
    }
    
    // 加载存储的网站内容
    const loadContent = () => {
      try {
        const storedContent = localStorage.getItem('siteContent');
        if (storedContent) {
          setContent(JSON.parse(storedContent));
          // 更新页面标题
          document.title = JSON.parse(storedContent).siteInfo.title;
        }
      } catch (error) {
        console.error('加载内容失败:', error);
      }
    };

    loadContent();
  }, []);

  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [activeCategory, setActiveCategory] = useState<ProjectCategory>("all");
  const [visibleProjects, setVisibleProjects] = useState<Project[]>(projectsData);
  const [isScrolled, setIsScrolled] = useState(false);

     const navLinks: NavLink[] = [{
        id: 1,
        label: "首页",
        href: "#home"
    }, {
        id: 3,
        label: "作品",
        href: "#work"
    }, {
        id: 2,
        label: "关于",
        href: "#about"
    }, {
        id: 4,
        label: "联系",
        href: "#contact"
    }];

    useEffect(() => {
        const handleScroll = () => {
            setIsScrolled(window.scrollY > 50);
        };

        window.addEventListener("scroll", handleScroll);
        const savedScrollPosition = localStorage.getItem("homeScrollPosition");

        if (savedScrollPosition) {
            window.scrollTo({
                top: parseInt(savedScrollPosition, 10),
                behavior: "smooth"
            });

            localStorage.removeItem("homeScrollPosition");
        }

        const handleBeforeUnload = () => {
            localStorage.setItem("homeScrollPosition", window.scrollY.toString());
        };

        window.addEventListener("beforeunload", handleBeforeUnload);

        return () => {
            window.removeEventListener("scroll", handleScroll);
            window.removeEventListener("beforeunload", handleBeforeUnload);
        };
    }, []);

    useEffect(() => {
        if (activeCategory === "all") {
            setVisibleProjects(projectsData);
        } else {
            setVisibleProjects(projectsData.filter(project => project.category === activeCategory));
        }
    }, [activeCategory]);

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const form = e.target as HTMLFormElement;
    const name = (form.elements.namedItem('name') as HTMLInputElement)?.value;
    const contact = (form.elements.namedItem('contact') as HTMLInputElement)?.value;
    const message = (form.elements.namedItem('message') as HTMLTextAreaElement)?.value;
    
    if (name && contact && message) {
      // 创建留言对象
      const newMessage = {
        id: Date.now(),
        name,
        contact,
        message,
        date: new Date().toLocaleString('zh-CN'),
        isRead: false
      };
      
      // 保存到localStorage
      try {
        const existingMessages = JSON.parse(localStorage.getItem('contactMessages') || '[]');
        existingMessages.push(newMessage);
        localStorage.setItem('contactMessages', JSON.stringify(existingMessages));
        toast("感谢您的留言，我会尽快回复您！");
        
        // 生产环境优化：可以添加真实的API调用
        if (import.meta.env.PROD) {
          // 这里可以添加实际的API调用代码
          console.log('Production environment: Submitting form data to server');
          // 示例: fetch('/api/contact', { method: 'POST', body: JSON.stringify(newMessage) })
        }
      } catch (error) {
        console.error('保存留言失败:', error);
        toast("保存留言失败，请稍后再试");
      }
      
      form.reset();
    } else {
      toast("请填写所有必填字段");
    }
  };

    const scrollToSection = (href: string) => {
        const element = document.querySelector(href);

        if (element) {
            element.scrollIntoView({
                behavior: "smooth"
            });
        }

        setIsMenuOpen(false);
    };

    return (
        <div
            className={`${theme === "dark" ? "bg-gray-950 text-gray-100" : "bg-white text-gray-900"} min-h-screen transition-colors duration-300`}>
            {}
            <motion.header
                className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${isScrolled ? `${isDark ? "bg-gray-950/90" : "bg-white/90"} backdrop-blur-md py-4 shadow-sm` : "py-6 bg-transparent"}`}
                initial={{
                    opacity: 0,
                    y: -20
                }}
                animate={{
                    opacity: 1,
                    y: 0
                }}
                transition={{
                    duration: 0.5
                }}>
                <div className="container mx-auto px-6 flex justify-between items-center">
                     <motion.div
                        className="text-2xl font-bold tracking-tight"
                        whileHover={{
                            scale: 1.03
                        }}>
                        Allin<span className="text-indigo-500">.</span>
                    </motion.div>
                    {}
                    <nav className="hidden md:flex items-center space-x-8">
                        {navLinks.map(link => <motion.button
                            key={link.id}
                            onClick={() => scrollToSection(link.href)}
                            className="relative text-sm font-medium tracking-wide hover:text-indigo-500 transition-colors"
                            whileHover={{
                                scale: 1.05
                            }}>
                            {link.label}
                            <motion.span
                                className="absolute -bottom-1 left-0 w-0 h-0.5 bg-indigo-500 transition-all"
                                whileHover={{
                                    width: "100%"
                                }} />
                        </motion.button>)}
                        <></>
                    </nav>
                    {}
                    <button
                        className="md:hidden p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-800 transition-colors"
                        onClick={() => setIsMenuOpen(!isMenuOpen)}
                        aria-label="Toggle menu">
                        {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
                    </button>
                </div>
                {}
                <AnimatePresence>
                    {isMenuOpen && <motion.div
                        className="md:hidden absolute top-full left-0 right-0 bg-white dark:bg-gray-900 shadow-lg"
                        initial={{
                            opacity: 0,
                            y: -10
                        }}
                        animate={{
                            opacity: 1,
                            y: 0
                        }}
                        exit={{
                            opacity: 0,
                            y: -10
                        }}
                        transition={{
                            duration: 0.3
                        }}>
                        <div className="container mx-auto px-6 py-4 flex flex-col space-y-4">
                            {navLinks.map(link => <button
                                key={link.id}
                                onClick={() => scrollToSection(link.href)}
                                className="py-2 text-left font-medium hover:text-indigo-500 transition-colors">
                                {link.label}
                            </button>)}
                            <button
                                onClick={toggleTheme}
                                className="py-2 flex items-center justify-between font-medium">
                                <span>{theme === "light" ? "切换到深色模式" : "切换到浅色模式"}</span>
                                {theme === "light" ? <svg
                                    xmlns="http://www.w3.org/2000/svg"
                                    width="20"
                                    height="20"
                                    viewBox="0 0 24 24"
                                    fill="none"
                                    stroke="currentColor"
                                    strokeWidth="2"
                                    strokeLinecap="round"
                                    strokeLinejoin="round">
                                    <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path>
                                </svg> : <svg
                                    xmlns="http://www.w3.org/2000/svg"
                                    width="20"
                                    height="20"
                                    viewBox="0 0 24 24"
                                    fill="none"
                                    stroke="currentColor"
                                    strokeWidth="2"
                                    strokeLinecap="round"
                                    strokeLinejoin="round">
                                    <circle cx="12" cy="12" r="5"></circle>
                                    <line x1="12" y1="1" x2="12" y2="3"></line>
                                    <line x1="12" y1="21" x2="12" y2="23"></line>
                                    <line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line>
                                    <line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line>
                                    <line x1="1" y1="12" x2="3" y2="12"></line>
                                    <line x1="21" y1="12" x2="23" y2="12"></line>
                                    <line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line>
                                    <line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line>
                                </svg>}
                            </button>
                        </div>
                    </motion.div>}
                </AnimatePresence>
            </motion.header>
            <main className="pt-24">
                {}
                <section id="home" className="min-h-[80vh] flex items-center relative overflow-hidden">
                    {/* 背景图片 */}
                    {content.heroSection.backgroundImage && (
                      <div 
                        className="absolute inset-0 z-0 bg-cover bg-center"
                        style={{ 
                          backgroundImage: `url(${content.heroSection.backgroundImage})`,
                          filter: 'brightness(0.7)' // 降低亮度以确保文本清晰可读
                        }}
                      />
                    )}
                    
                    {/* 渐变遮罩，提升文本可读性 */}
                    <div className="absolute inset-0 z-10 bg-gradient-to-r from-black/70 to-black/40 md:from-black/50 md:to-black/20" />
                    
                    <div className="container mx-auto px-6 relative z-20">
                        <motion.div
                            className="max-w-3xl mx-auto text-center text-white"
                            initial={{
                                opacity: 0,
                                y: 20
                            }}
                            animate={{
                                opacity: 1,
                                y: 0
                            }}
                            transition={{
                                duration: 0.8
                            }}>
                             <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold mb-6 leading-tight">{content.heroSection.heading.split('，')[0]}<span className="text-indigo-400">{content.heroSection.heading.split('，')[1]}</span>
                             </h1>
                             <p
                                 className="text-lg md:text-xl text-gray-200 mb-10 leading-relaxed">{content.heroSection.subheading}
                             </p>
                             <div className="flex flex-col sm:flex-row justify-center gap-4">
                               <motion.button
                                   onClick={() => scrollToSection("#work")}
                                   className="px-8 py-3 bg-indigo-500 text-white rounded-md font-medium flex items-center justify-center gap-2 hover:bg-indigo-600 transition-colors"
                                   whileHover={{
                                       scale: 1.03
                                   }}
                                   whileTap={{
                                       scale: 0.98
                                   }}>{content.heroSection.buttonText} <ArrowRight size={18} />
                               </motion.button>
                               <></>
                             </div>
                        </motion.div>
                    </div>
                </section>
                {}
                {}

                {}
                {}
                {}
                <section id="work" className="py-24">
                    <div className="container mx-auto px-6">
                        <motion.div
                            className="max-w-6xl mx-auto"
                            initial={{
                                opacity: 0
                            }}
                            whileInView={{
                                opacity: 1
                            }}
                            viewport={{
                                once: true
                            }}
                            transition={{
                                duration: 0.8
                            }}>
                            <div className="text-center mb-16">
                                <h2 className="text-3xl md:text-4xl font-bold mb-4">我的作品</h2>
                                <p
                                    className={`max-w-2xl mx-auto ${isDark ? "text-gray-400" : "text-gray-600"}`}>探索我的创意项目，每一个作品都代表着独特的设计理念和解决方案
                                                                                                                                                                                                                                                                                </p>
                            </div>
                            {}
                            <div className="flex flex-wrap justify-center gap-4 mb-12">
                                {["all", "web", "graphic", "branding", "ui"].map(category => <motion.button
                                    key={category}
                                    onClick={() => setActiveCategory(category as ProjectCategory)}
                                    className={`px-5 py-2 rounded-full text-sm font-medium transition-colors ${activeCategory === category ? "bg-indigo-500 text-white" : isDark ? "bg-gray-800 text-gray-300 hover:bg-gray-700" : "bg-gray-100 text-gray-700 hover:bg-gray-200"}`}
                                    whileHover={{
                                        scale: 1.05
                                    }}
                                    whileTap={{
                                        scale: 0.95
                                    }}>
                                    {category === "all" ? "全部" : category === "web" ? "网页设计" : category === "graphic" ? "平面设计" : category === "branding" ? "品牌设计" : "UI设计"}
                                </motion.button>)}
                            </div>
                            {}
                            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                                <AnimatePresence>
                                    {visibleProjects.map(project => <motion.a
                                        key={project.id}
                                        href={`/project/${project.id}`}
                                        className={`rounded-lg overflow-hidden ${isDark ? "bg-gray-900" : "bg-white"} shadow-lg block group`}
                                        initial={{
                                            opacity: 0,
                                            y: 20
                                        }}
                                        animate={{
                                            opacity: 1,
                                            y: 0
                                        }}
                                        exit={{
                                            opacity: 0,
                                            y: -20
                                        }}
                                        whileHover={{
                                            y: -10,
                                            boxShadow: isDark ? "0 20px 25px -5px rgba(0, 0, 0, 0.3), 0 10px 10px -5px rgba(0, 0, 0, 0.2)" : "0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)"
                                        }}
                                        transition={{
                                            duration: 0.3
                                        }}>
                                        <div className="aspect-video overflow-hidden relative">
                                            <img
                                                src={project.imageUrl}
                                                alt={project.title}
                                                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
                                            <div
                                                className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end">
                                                <div className="p-6 w-full">
                                                    <span
                                                        className="inline-block px-3 py-1.5 bg-white/20 backdrop-blur-sm text-white text-xs font-medium rounded-full">点击查看详情
                                                                                                                                                                        </span>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="p-6">
                                            <span
                                                className={`inline-block px-3 py-1 text-xs font-medium rounded-full mb-3 ${project.category === "web" ? "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200" : project.category === "graphic" ? "bg-pink-100 text-pink-800 dark:bg-pink-900 dark:text-pink-200" : project.category === "branding" ? "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200" : "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200"}`}>
                                                {project.category === "web" ? "网页设计" : project.category === "graphic" ? "平面设计" : project.category === "branding" ? "品牌设计" : "UI设计"}
                                            </span>
                                            <h3
                                                className="text-xl font-semibold mb-2 group-hover:text-indigo-500 transition-colors">{project.title}</h3>
                                            <p
                                                className={`mb-4 text-base leading-relaxed ${isDark ? "text-gray-400" : "text-gray-600"}`}>
                                                {project.description}
                                            </p>
                                            <></>
                                        </div>
                                    </motion.a>)}
                                </AnimatePresence>
                            </div>
                            {}
                            {visibleProjects.length === 0 && <div className="text-center py-20">
                                <p className={`text-lg ${isDark ? "text-gray-400" : "text-gray-500"}`}>暂无该分类的作品
                                                                                                                                                                                                                                                                                  </p>
                            </div>}
                        </motion.div>
                    </div>
                </section>
                {}
                <section id="about" className={`py-24 ${isDark ? "bg-gray-900" : "bg-gray-50"}`}>
                    <div className="container mx-auto px-6">
                        <motion.div
                            className="max-w-6xl mx-auto"
                            initial={{
                                opacity: 0
                            }}
                            whileInView={{
                                opacity: 1
                            }}
                            viewport={{
                                once: true
                            }}
                            transition={{
                                duration: 0.8
                            }}>
                             <div className="text-center mb-16">
                               <h2 className="text-3xl md:text-4xl font-bold mb-4">{content.aboutSection.title}</h2>
                               <p
                                   className={`max-w-2xl mx-auto ${isDark ? "text-gray-400" : "text-gray-600"}`}>{content.aboutSection.subtitle}
                              </p>
                             </div>
                             <div className="grid grid-cols-1 md:grid-cols-2 gap-10 items-center">
                               <motion.div
                                   initial={{
                                       opacity: 0,
                                       x: -30
                                   }}
                                   whileInView={{
                                       opacity: 1,
                                       x: 0
                                   }}
                                   viewport={{
                                       once: true
                                   }}
                                   transition={{
                                       duration: 0.6,
                                       delay: 0.2
                                   }}
                                    className="relative mx-auto"
                                    style={{ maxWidth: '66%' }}>
                                  <div
                                      className={`rounded-2xl overflow-hidden shadow-xl ${isDark ? "shadow-gray-800/50" : "shadow-gray-200"} transform scale-120 origin-center`}>
                                    <img
                                        src={content.aboutSection.imageUrl}
                                        alt={content.aboutSection.designerName}
                                        className="w-full h-auto object-cover"
                                        loading="lazy" />
                                  </div>
                                 <div
                                     className={`absolute -bottom-6 -right-6 p-5 rounded-xl shadow-lg ${isDark ? "bg-gray-800" : "bg-white"}`}>
                                   <div className="text-4xl font-bold">{content.aboutSection.experience}</div>
                                   <div className={`${isDark ? "text-gray-400" : "text-gray-600"}`}>年设计经验</div>
                                 </div>
                               </motion.div>
                               <motion.div
                                   initial={{
                                       opacity: 0,
                                       x: 30
                                   }}
                                   whileInView={{
                                       opacity: 1,
                                       x: 0
                                   }}
                                   viewport={{
                                       once: true
                                   }}
                                   transition={{
                                       duration: 0.6,
                                       delay: 0.3
                                   }}>
                                 <h3 className="text-2xl font-bold mb-4">{content.aboutSection.designerName}</h3>
                                 <p
                                     className={`text-lg mb-6 ${isDark ? "text-gray-300" : "text-gray-700"} leading-relaxed`}>{content.aboutSection.bio1}
                                </p>
                                 <p
                                     className={`text-lg mb-8 ${isDark ? "text-gray-300" : "text-gray-700"} leading-relaxed`}>{content.aboutSection.bio2}
                                </p>
                                 <div className="grid grid-cols-2 gap-6 mb-8">
                                   <div>
                                     <h4 className="font-semibold mb-3">设计专长</h4>
                                     <ul className={`space-y-2 ${isDark ? "text-gray-400" : "text-gray-600"}`}>
                                       {content.aboutSection.skills.map((skill, index) => (
                                         <li key={index} className="flex items-center gap-2">
                                           <i className="fa-solid fa-check-circle text-indigo-500"></i>{skill}
                                          </li>
                                       ))}
                                     </ul>
                                   </div>
                                   <div>
                                     <h4 className="font-semibold mb-3">使用工具</h4>
                                     <ul className={`space-y-2 ${isDark ? "text-gray-400" : "text-gray-600"}`}>
                                       {content.aboutSection.tools.map((tool, index) => (
                                         <li key={index} className="flex items-center gap-2">
                                           <i className="fa-solid fa-check-circle text-indigo-500"></i>{tool}
                                          </li>
                                       ))}
                                     </ul>
                                   </div>
                                 </div>
                                 <></>
                               </motion.div>
                            </div>
                            {}
                            <></>
                        </motion.div>
                    </div>
                </section>
                {}
                <section
                    id="contact"
                    className={`py-20 md:py-24 ${isDark ? "bg-gray-900" : "bg-gray-50"}`}>
                    <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                        <motion.div
                            className="max-w-5xl mx-auto"
                            initial={{
                                opacity: 0
                            }}
                            whileInView={{
                                opacity: 1
                            }}
                            viewport={{
                                once: true
                            }}
                            transition={{
                                duration: 0.8
                            }}>
                             <div className="text-center mb-12 md:mb-16">
                               <h2 className="text-3xl md:text-4xl font-bold mb-4">{content.contactSection.title}</h2>
                               <p
                                   className={`max-w-2xl mx-auto ${isDark ? "text-gray-400" : "text-gray-600"}`}>{content.contactSection.subtitle}
                              </p>
                             </div>
                             {}
                             <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-10">
                               {}
                               <motion.div
                                   initial={{
                                       x: -20,
                                       opacity: 0
                                   }}
                                   whileInView={{
                                       x: 0,
                                       opacity: 1
                                   }}
                                   viewport={{
                                       once: true
                                   }}
                                   transition={{
                                       duration: 0.5,
                                       delay: 0.2
                                   }}>
                                 <div
                                     className={`rounded-lg p-6 ${isDark ? "bg-gray-800" : "bg-white shadow-lg"}`}>
                                   <form onSubmit={handleContactSubmit} className="space-y-5">
                                     <div className="space-y-2">
                                       <label
                                           htmlFor="name"
                                           className={`block text-sm font-medium ${isDark ? "text-gray-300" : "text-gray-700"}`}>单位
                                      </label>
                                       <input
                                           type="text"
                                           id="name"
                                           className={`w-full px-4 py-3 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all ${isDark ? "bg-gray-700 border border-gray-600 text-white placeholder-gray-400" : "bg-white border border-gray-300 text-gray-900 placeholder-gray-400"}`}
                                           placeholder="请输入您的单位名称"
                                           required />
                                     </div>
                                     <div className="space-y-2">
                                       <label
                                           htmlFor="contact"
                                           className={`block text-sm font-medium ${isDark ? "text-gray-300" : "text-gray-700"}`}>联系方式
                                      </label>
                                       <input
                                           type="text"
                                           id="contact"
                                           className={`w-full px-4 py-3 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all ${isDark ? "bg-gray-700 border border-gray-600 text-white placeholder-gray-400" : "bg-white border border-gray-300 text-gray-900 placeholder-gray-400"}`}
                                           placeholder="请输入您的电话或邮箱"
                                           required />
                                     </div>
                                     <div className="space-y-2">
                                       <label
                                           htmlFor="message"
                                           className={`block text-sm font-medium ${isDark ? "text-gray-300" : "text-gray-700"}`}>留言
                                      </label>
                                       <textarea
                                           id="message"
                                           rows={5}
                                           className={`w-full px-4 py-3 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all ${isDark ? "bg-gray-700 border border-gray-600 text-white placeholder-gray-400" : "bg-white border border-gray-300 text-gray-900 placeholder-gray-400"}`}
                                           placeholder="请输入您的留言内容"
                                           required />
                                     </div>
                                     <motion.button
                                         type="submit"
                                         className="w-full px-6 py-3 bg-indigo-500 text-white rounded-md font-medium hover:bg-indigo-600 transition-colors"
                                         whileHover={{
                                             scale: 1.02
                                         }}
                                         whileTap={{
                                             scale: 0.98
                                         }}>发送留言
                                      </motion.button>
                                   </form>
                                 </div>
                               </motion.div>
                               {}
                               <motion.div
                                   initial={{
                                       x: 20,
                                       opacity: 0
                                   }}
                                   whileInView={{
                                       x: 0,
                                       opacity: 1
                                   }}
                                   viewport={{
                                       once: true
                                   }}
                                   transition={{
                                       duration: 0.5,
                                       delay: 0.3
                                   }}>
                                 <div
                                     className={`rounded-lg p-6 h-full flex flex-col ${isDark ? "bg-gray-800" : "bg-white shadow-lg"}`}>
                                    <h3 className="text-xl font-bold mb-5">联系方式</h3>
                                     <div className="space-y-8 flex-grow md:py-8">
                                     {}<div className="flex items-start gap-4">
                                       <div
                                           className="mt-0.5 p-2 rounded-full bg-indigo-100 dark:bg-indigo-900 text-indigo-600 dark:text-indigo-200 flex-shrink-0">
                                         <svg
                                             xmlns="http://www.w3.org/2000/svg"
                                             width="18"
                                             height="18"
                                             viewBox="0 0 24 24"
                                             fill="none"
                                             stroke="currentColor"
                                             strokeWidth="2"
                                             strokeLinecap="round"
                                             strokeLinejoin="round">
                                           <path
                                               d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
                                         </svg>
                                       </div>
                                       <div>
                                         <h4 className="text-sm font-medium mb-1">电话</h4>
                                         <a
                                             href={`tel:${content.contactSection.phone}`}
                                             className={`${isDark ? "text-gray-300 hover:text-white" : "text-gray-700 hover:text-gray-900"} transition-colors`}>{content.contactSection.phone}
                                          </a>
                                       </div>
                                     </div>
                                     {}
                                     <div className="flex items-start gap-4">
                                       <div
                                           className="mt-0.5 p-2 rounded-full bg-indigo-100 dark:bg-indigo-900 text-indigo-600 dark:text-indigo-200 flex-shrink-0">
                                         <svg
                                             xmlns="http://www.w3.org/2000/svg"
                                             width="18"
                                             height="18"
                                             viewBox="0 0 24 24"
                                             fill="none"
                                             stroke="currentColor"
                                             strokeWidth="2"
                                             strokeLinecap="round"
                                             strokeLinejoin="round">
                                           <path
                                               d="M12 2a10 10 0 0 0-9.95 9h11.64L9.74 7.05a1 1 0 0 1 1.41-1.41l5.66 5.65a1 1 0 0 1 0 1.42l-5.66 5.65a1 1 0 0 1-1.41-1.41L13.69 13H2.05A10 10 0 1 0 12 2z"></path>
                                         </svg>
                                       </div>
                                       <div>
                                         <h4 className="text-sm font-medium mb-1">微信</h4>
                                         <span className={`${isDark ? "text-gray-300" : "text-gray-700"}`}>{content.contactSection.wechat}
                                          </span>
                                       </div>
                                     </div>
                                     {}
                                     <div className="flex items-start gap-4">
                                       <div
                                           className="mt-0.5 p-2 rounded-full bg-indigo-100 dark:bg-indigo-900 text-indigo-600 dark:text-indigo-200 flex-shrink-0">
                                         <Mail size={18} />
                                       </div>
                                       <div>
                                         <h4 className="text-sm font-medium mb-1">邮箱</h4>
                                         <a
                                             href={`mailto:${content.contactSection.email}`}
                                             className={`${isDark ? "text-gray-300 hover:text-white" : "text-gray-700 hover:text-gray-900"} transition-colors`}>{content.contactSection.email}
                                          </a>
                                       </div>
                                     </div>
                                   </div>
                                   <div className="mt-6 pt-4 border-t border-gray-200 dark:border-gray-700">
                                     <p className={`${isDark ? "text-gray-400" : "text-gray-600"} text-sm`}>{content.contactSection.responseTimeText}
                                      </p>
                                   </div>
                                 </div>
                               </motion.div>
                            </div>
                        </motion.div>
                    </div>
                </section>
            </main>
            {}
            <footer className={`py-12 ${isDark ? "bg-gray-950" : "bg-gray-100"}`}>
                <div className="container mx-auto px-6">
                    <div className="max-w-6xl mx-auto">
                        <div className="flex flex-col md:flex-row justify-between items-center">
                             <div className="mb-6 md:mb-0">
                               <div className="text-2xl font-bold tracking-tight mb-2">Alex<span className="text-indigo-500">.</span>
                               </div>
                               <p className={`text-sm ${isDark ? "text-gray-400" : "text-gray-600"}`}>{content.footerSection.footerDescription}
                              </p>
                             </div>
                             <></>
                             <div className="flex flex-col items-center sm:flex-row gap-4">
                               <div className={`text-sm ${isDark ? "text-gray-500" : "text-gray-600"}`}>{content.footerSection.copyrightText}</div>

                            </div>
                        </div>
                    </div>
                </div>
            </footer>
        </div>
    );
}
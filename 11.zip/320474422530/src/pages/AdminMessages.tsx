import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { LogOut, Home, Edit, Check, X, Trash2, Mail, Filter, Search, ArrowUpRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { useTheme } from '@/hooks/useTheme';
import { useAuth } from '@/contexts/authContext.tsx';

// 定义留言类型
interface ContactMessage {
  id: number;
  name: string;
  contact: string;
  message: string;
  date: string;
  isRead: boolean;
}

// 管理员留言管理页面
const AdminMessages: React.FC = () => {
  const navigate = useNavigate();
  const { logout, isAuthenticated } = useAuth();
  const { isDark } = useTheme();
  const [messages, setMessages] = useState<ContactMessage[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'unread' | 'read'>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedMessage, setSelectedMessage] = useState<ContactMessage | null>(null);

  // 检查认证状态
  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/admin/login');
    }
  }, [isAuthenticated, navigate]);

  // 加载留言数据
  useEffect(() => {
    const loadMessages = () => {
      setIsLoading(true);
      try {
        const storedMessages = localStorage.getItem('contactMessages');
        if (storedMessages) {
          setMessages(JSON.parse(storedMessages));
        } else {
          setMessages([]);
        }
      } catch (error) {
        console.error('加载留言失败:', error);
        toast('加载留言列表失败');
        setMessages([]);
      } finally {
        setIsLoading(false);
      }
    };

    loadMessages();
  }, []);

  // 处理登出
  const handleLogout = () => {
    logout();
    toast('已成功退出登录');
  };

  // 标记留言为已读
  const markAsRead = (id: number) => {
    try {
      const updatedMessages = messages.map(message => 
        message.id === id ? { ...message, isRead: true } : message
      );
      setMessages(updatedMessages);
      localStorage.setItem('contactMessages', JSON.stringify(updatedMessages));
      
      // 如果当前选中的是这条留言，也更新选中的留言状态
      if (selectedMessage && selectedMessage.id === id) {
        setSelectedMessage({ ...selectedMessage, isRead: true });
      }
      
      toast('标记为已读成功');
    } catch (error) {
      console.error('标记失败:', error);
      toast('标记失败，请重试');
    }
  };

  // 删除留言
  const deleteMessage = (id: number) => {
    if (window.confirm('确定要删除这条留言吗？')) {
      try {
        const updatedMessages = messages.filter(message => message.id !== id);
        setMessages(updatedMessages);
        localStorage.setItem('contactMessages', JSON.stringify(updatedMessages));
        
        // 如果当前选中的是这条留言，清除选中状态
        if (selectedMessage && selectedMessage.id === id) {
          setSelectedMessage(null);
        }
        
        toast('留言删除成功');
      } catch (error) {
        console.error('删除失败:', error);
        toast('删除失败，请重试');
      }
    }
  };

  // 删除所有留言
  const deleteAllMessages = () => {
    if (messages.length === 0) {
      toast('没有可删除的留言');
      return;
    }
    
    if (window.confirm(`确定要删除所有${messages.length}条留言吗？此操作不可恢复。`)) {
      try {
        setMessages([]);
        localStorage.removeItem('contactMessages');
        setSelectedMessage(null);
        toast('所有留言已删除');
      } catch (error) {
        console.error('删除失败:', error);
        toast('删除失败，请重试');
      }
    }
  };

  // 筛选留言
  const filteredMessages = messages.filter(message => {
    // 应用过滤条件
    const matchesFilter = 
      filter === 'all' || 
      (filter === 'unread' && !message.isRead) || 
      (filter === 'read' && message.isRead);
    
    // 应用搜索条件
    const matchesSearch = 
      !searchTerm || 
      message.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      message.contact.toLowerCase().includes(searchTerm.toLowerCase()) ||
      message.message.toLowerCase().includes(searchTerm.toLowerCase()) ||
      message.date.toLowerCase().includes(searchTerm.toLowerCase());
    
    return matchesFilter && matchesSearch;
  });

  // 获取未读留言数量
  const unreadCount = messages.filter(message => !message.isRead).length;

  return (
    <div className={`min-h-screen ${isDark ? 'bg-gray-950 text-white' : 'bg-gray-50 text-gray-900'} transition-colors duration-300`}>
      {/* 顶部导航 */}
      <motion.header
        className={`sticky top-0 z-40 w-full py-4 ${isDark ? 'bg-gray-900/90' : 'bg-white/90'} backdrop-blur-md shadow-sm`}
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="container mx-auto px-6 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Mail size={24} className="text-indigo-500" />
            <h1 className="text-xl font-bold">留言管理后台</h1>
          </div>
          
          <div className="flex gap-3">
            <motion.button
              onClick={() => navigate('/admin/content')}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors ${
                isDark ? 'bg-gray-800 hover:bg-gray-700' : 'bg-gray-100 hover:bg-gray-200'
              }`}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Edit size={16} />
              内容管理
            </motion.button>
            
            <motion.button
              onClick={() => navigate('/admin/upload')}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors ${
                isDark ? 'bg-gray-800 hover:bg-gray-700' : 'bg-gray-100 hover:bg-gray-200'
              }`}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Edit size={16} />
              作品上传
            </motion.button>
            
            <motion.button
              onClick={() => navigate('/')}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors ${
                isDark ? 'bg-gray-800 hover:bg-gray-700' : 'bg-gray-100 hover:bg-gray-200'
              }`}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Home size={16} />
              返回首页
            </motion.button>
            
            <motion.button
              onClick={handleLogout}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors ${
                isDark ? 'bg-gray-800 hover:bg-gray-700' : 'bg-gray-100 hover:bg-gray-200'
              }`}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <LogOut size={16} />
              退出登录
            </motion.button>
          </div>
        </div>
      </motion.header>

      <main className="container mx-auto px-6 py-10 max-w-6xl">
        {/* 留言管理卡片 */}
        <motion.div
          className={`p-8 rounded-xl shadow-lg ${isDark ? 'bg-gray-900' : 'bg-white'} border ${isDark ? 'border-gray-800' : 'border-gray-100'}`}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2 rounded-full bg-indigo-100 text-indigo-600 dark:bg-indigo-900/30 dark:text-indigo-400">
              <Mail size={24} />
            </div>
            <h2 className="text-2xl font-bold">留言管理</h2>
            {unreadCount > 0 && (
              <span className="px-2 py-1 text-xs font-medium bg-red-500 text-white rounded-full">
                {unreadCount} 条未读
              </span>
            )}
          </div>
          
          {/* 操作工具栏 */}
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
            <div className="flex items-center gap-2">
              <span className="text-sm text-gray-500 dark:text-gray-400">
                共 {messages.length} 条留言，{unreadCount} 条未读
              </span>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4 w-full md:w-auto">
              {/* 搜索框 */}
              <div className="relative flex-grow sm:flex-grow-0 w-full sm:w-64">
                <input
                  type="text"
                  placeholder="搜索留言..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className={`w-full pl-10 pr-4 py-2 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all ${
                    isDark 
                      ? 'bg-gray-800 border border-gray-700 text-white placeholder-gray-500' 
                      : 'bg-white border border-gray-300 text-gray-900 placeholder-gray-400'
                  }`}
                />
                <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
              </div>
              
              {/* 筛选按钮 */}
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setFilter('all')}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                    filter === 'all' 
                      ? 'bg-indigo-500 text-white' 
                      : isDark 
                        ? 'bg-gray-800 text-gray-300 hover:bg-gray-700' 
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  全部
                </button>
                <button
                  onClick={() => setFilter('unread')}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                    filter === 'unread' 
                      ? 'bg-indigo-500 text-white' 
                      : isDark 
                        ? 'bg-gray-800 text-gray-300 hover:bg-gray-700' 
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  未读
                  {unreadCount > 0 && (
                    <span className="ml-1 text-xs bg-red-500 text-white px-1.5 py-0.5 rounded-full">
                      {unreadCount}
                    </span>
                  )}
                </button>
                <button
                  onClick={() => setFilter('read')}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                    filter === 'read' 
                      ? 'bg-indigo-500 text-white' 
                      : isDark 
                        ? 'bg-gray-800 text-gray-300 hover:bg-gray-700' 
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  已读
                </button>
              </div>
              
              {/* 删除所有按钮 */}
              <motion.button
                onClick={deleteAllMessages}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                  isDark 
                    ? 'bg-red-900/30 text-red-400 hover:bg-red-900/50' 
                    : 'bg-red-50 text-red-600 hover:bg-red-100'
                }`}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <Trash2 size={16} />
                删除所有
              </motion.button>
            </div>
          </div>
          
          {/* 留言列表和详情区域 */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* 留言列表 */}
            <div className={`lg:col-span-1 rounded-lg ${isDark ? 'bg-gray-800' : 'bg-gray-50'} overflow-hidden`}>
              {isLoading ? (
                // 加载状态
                <div className="p-6 space-y-4">
                  {Array(5).fill(0).map((_, index) => (
                    <motion.div 
                      key={index}
                      className="p-4 rounded-lg bg-white dark:bg-gray-900 animate-pulse"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ delay: index * 0.1 }}
                    >
                      <div className="h-4 bg-gray-300 dark:bg-gray-700 rounded w-3/4 mb-3"></div>
                      <div className="h-3 bg-gray-200 dark:bg-gray-600 rounded w-1/2 mb-2"></div>
                      <div className="h-3 bg-gray-200 dark:bg-gray-600 rounded w-full"></div>
                    </motion.div>
                  ))}
                </div>
              ) : filteredMessages.length === 0 ? (
                // 空状态
                <div className="p-8 text-center">
                  <Mail size={48} className={`mx-auto mb-4 opacity-30 ${isDark ? 'text-gray-600' : 'text-gray-400'}`} />
                  <h3 className="text-lg font-medium mb-2">暂无留言</h3>
                  <p className={`${isDark ? 'text-gray-500' : 'text-gray-400'}`}>
                    {searchTerm ? '没有找到匹配的留言' : '还没有用户给您留言'}
                  </p>
                </div>
              ) : (
                // 留言列表
                <div className="divide-y divide-gray-200 dark:divide-gray-700">
                  {filteredMessages.map(message => (
                    <motion.div
                      key={message.id}
                      onClick={() => {
                        setSelectedMessage(message);
                        // 如果是未读留言，点击后标记为已读
                        if (!message.isRead) {
                          markAsRead(message.id);
                        }
                      }}
                      className={`p-4 cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-700/50 transition-colors ${
                        selectedMessage?.id === message.id 
                          ? isDark ? 'bg-gray-700/50' : 'bg-gray-100' 
                          : ''
                      } ${!message.isRead ? 'bg-indigo-50 dark:bg-indigo-900/20' : ''}`}
                      whileHover={{ scale: 1.01 }}
                      whileTap={{ scale: 0.99 }}
                    >
                      <div className="flex items-start justify-between">
                        <h3 className="font-medium">{message.name}</h3>
                        {!message.isRead && (
                          <span className="w-2 h-2 rounded-full bg-red-500 mt-1.5"></span>
                        )}
                      </div>
                      <p className={`text-sm mt-1 line-clamp-2 ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
                        {message.message}
                      </p>
                      <div className={`text-xs mt-2 ${isDark ? 'text-gray-500' : 'text-gray-500'}`}>
                        {message.date}
                      </div>
                    </motion.div>
                  ))}
                </div>
              )}
            </div>
            
            {/* 留言详情 */}
            <div className={`lg:col-span-2 rounded-lg ${isDark ? 'bg-gray-800' : 'bg-gray-50'} overflow-hidden flex flex-col`}>
              {selectedMessage ? (
                <motion.div 
                  className="p-6 flex-grow"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ duration: 0.3 }}
                >
                  <div className="flex justify-between items-start mb-6">
                    <div>
                      <h3 className="text-xl font-bold">{selectedMessage.name}</h3>
                      <p className={`text-sm mt-1 ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
                        {selectedMessage.date}
                      </p>
                    </div>
                    <div className="flex gap-2">
                      {!selectedMessage.isRead && (
                        <motion.button
                          onClick={() => markAsRead(selectedMessage.id)}
                          className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
                            isDark 
                              ? 'bg-green-900/30 text-green-400 hover:bg-green-900/50' 
                              : 'bg-green-50 text-green-600 hover:bg-green-100'
                          }`}
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                        >
                          <Check size={14} />
                          标记为已读
                        </motion.button>
                      )}
                      <motion.button
                        onClick={() => deleteMessage(selectedMessage.id)}
                        className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
                          isDark 
                            ? 'bg-red-900/30 text-red-400 hover:bg-red-900/50' 
                            : 'bg-red-50 text-red-600 hover:bg-red-100'
                        }`}
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                      >
                        <Trash2 size={14} />
                        删除
                      </motion.button>
                    </div>
                  </div>
                  
                  <div className={`p-5 rounded-lg mb-6 ${isDark ? 'bg-gray-900' : 'bg-white'}`}>
                    <h4 className="text-sm font-medium mb-3">联系方式</h4>
                    <a 
                      href={selectedMessage.contact.includes('@') ? `mailto:${selectedMessage.contact}` : `tel:${selectedMessage.contact}`}
                      className="text-indigo-500 hover:text-indigo-600 flex items-center gap-1"
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      {selectedMessage.contact}
                      <ArrowUpRight size={14} />
                    </a>
                  </div>
                  
                  <div className={`p-5 rounded-lg ${isDark ? 'bg-gray-900' : 'bg-white'}`}>
                    <h4 className="text-sm font-medium mb-3">留言内容</h4>
                    <p className={`whitespace-pre-wrap ${isDark ? 'text-gray-300' : 'text-gray-700'}`}>
                      {selectedMessage.message}
                    </p>
                  </div>
                </motion.div>
              ) : (
                <div className="flex-grow flex flex-col items-center justify-center p-6 text-center">
                  <Mail size={64} className={`mb-4 opacity-30 ${isDark ? 'text-gray-600' : 'text-gray-400'}`} />
                  <h3 className="text-xl font-medium mb-2">选择一条留言</h3>
                  <p className={`max-w-md ${isDark ? 'text-gray-500' : 'text-gray-400'}`}>
                    从左侧列表中点击一条留言查看详情
                  </p>
                </div>
              )}
            </div>
          </div>
        </motion.div>
      </main>
    </div>
  );
};

export default AdminMessages;
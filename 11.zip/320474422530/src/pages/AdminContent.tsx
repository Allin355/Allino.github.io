import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { LogOut, Home, Edit, Image, Check, X, ArrowLeft, ArrowRight, Mail } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { useTheme } from '@/hooks/useTheme';
import { useAuth } from '@/contexts/authContext.tsx';

// 定义网站内容的类型
interface SiteContent {
  // 网站基本信息
  siteInfo: {
    title: string;
    description: string;
  };
  
  // 英雄区内容
  heroSection: {
    heading: string;
    subheading: string;
    buttonText: string;
    backgroundImage?: string; // 新增背景图片字段
  };
  
  // 关于设计师板块
  aboutSection: {
    title: string;
    subtitle: string;
    designerName: string;
    bio1: string;
    bio2: string;
    experience: string;
    skills: string[];
    tools: string[];
    imageUrl: string;
  };
  
  // 联系部分
  contactSection: {
    title: string;
    subtitle: string;
    phone: string;
    wechat: string;
    email: string;
    responseTimeText: string;
  };
  
  // 页脚内容
  footerSection: {
    copyrightText: string;
    footerDescription: string;
  };
}

// 默认网站内容
const defaultContent: SiteContent = {
  siteInfo: {
    title: "Alex Design Studio | 简约高级的设计作品",
    description: "专注于创造简约而富有意义的设计作品，致力于将复杂的问题转化为直观优雅的解决方案。"
  },
  
  heroSection: {
    heading: "用设计解决问题，以创意创造价值",
    subheading: "我是Alex，一位专注于创造简约而富有意义的设计作品的设计师，致力于将复杂的问题转化为直观优雅的解决方案。",
    buttonText: "查看我的作品",
    backgroundImage: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Modern%20design%20workspace%20with%20minimalist%20aesthetics%20and%20creative%20atmosphere&sign=fbb11bf9a7ba089301e4b4ad4444a446" // 新增背景图片
  },
  
  aboutSection: {
    title: "关于设计师",
    subtitle: "专注于创造简约而富有意义的设计作品，致力于将复杂的问题转化为直观优雅的解决方案",
    designerName: "Alex Chen",
    bio1: "你好，我是Alex，一位充满热情的设计师，专注于品牌设计、网页设计和用户界面设计。我相信设计不仅仅是表面的美观，更是解决问题和创造有意义体验的强大工具。",
    bio2: "我的设计理念是将复杂的问题简化，通过清晰的视觉语言和直观的用户体验，帮助品牌与目标受众建立真实的连接。每个项目对我来说都是一次新的探索和创造机会。",
    experience: "10+",
    skills: ["品牌识别设计", "网页与交互设计", "用户界面设计", "响应式设计"],
    tools: ["Adobe Creative Suite", "Figma", "Sketch", "Webflow"],
    imageUrl: "https://space.coze.cn/api/coze_space/gen_image?image_size=portrait_4_3&prompt=Portrait%20of%20a%20modern%20graphic%20designer%20working%20in%20a%20studio&sign=4f2f6f7f6bfc07238629c6615ea5a092"
  },
  
  contactSection: {
    title: "联系我",
    subtitle: "对我的作品感兴趣或者有合作意向？请随时联系我，我很期待与您交流",
    phone: "13553551446",
    wechat: "two193667280",
    email: "2331748170@qq.com",
    responseTimeText: "我通常会在24小时内回复您的邮件和消息"
  },
  
  footerSection: {
    copyrightText: `© ${new Date().getFullYear()} Alex Design Studio. 保留所有权利。`,
    footerDescription: "创造简约而有意义的设计"
  }
};

// 管理员内容管理页面
const AdminContent: React.FC = () => {
  const navigate = useNavigate();
  const { logout, isAuthenticated } = useAuth();
  const { isDark } = useTheme();
  const [content, setContent] = useState<SiteContent>(defaultContent);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccessMessage, setShowSuccessMessage] = useState(false);
  const [activeTab, setActiveTab] = useState<string>('hero');

  // 检查认证状态
  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/admin/login');
    }
  }, [isAuthenticated, navigate]);

  // 加载已保存的内容
  useEffect(() => {
    const loadContent = () => {
      try {
        const storedContent = localStorage.getItem('siteContent');
        if (storedContent) {
          setContent(JSON.parse(storedContent));
        }
      } catch (error) {
        console.error('加载内容失败:', error);
        toast('加载网站内容失败');
      }
    };

    loadContent();
  }, []);

  // 处理登出
  const handleLogout = () => {
    logout();
    toast('已成功退出登录');
  };

  // 处理表单字段变化
  const handleChange = (section: keyof SiteContent, field: string, value: string) => {
    setContent(prev => ({
      ...prev,
      [section]: {
        ...prev[section],
        [field]: value
      }
    }));
  };

  // 处理数组字段变化
  const handleArrayChange = (section: keyof SiteContent, field: string, index: number, value: string) => {
    const newArray = [...(content[section] as any)[field]];
    newArray[index] = value;
    setContent(prev => ({
      ...prev,
      [section]: {
        ...prev[section],
        [field]: newArray
      }
    }));
  };

  // 添加数组项
  const addArrayItem = (section: keyof SiteContent, field: string) => {
    const currentArray = (content[section] as any)[field] || [];
    setContent(prev => ({
      ...prev,
      [section]: {
        ...prev[section],
        [field]: [...currentArray, '']
      }
    }));
  };

  // 移除数组项
  const removeArrayItem = (section: keyof SiteContent, field: string, index: number) => {
    const currentArray = (content[section] as any)[field] || [];
    if (currentArray.length <= 1) return; // 至少保留一项
    
    const newArray = currentArray.filter((_, i: number) => i !== index);
    setContent(prev => ({
      ...prev,
      [section]: {
        ...prev[section],
        [field]: newArray
      }
    }));
  };

  // 处理图片上传
  const handleImageUpload = (section: keyof SiteContent, field: string, e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      
      // 检查文件类型是否为图片
      if (!file.type.startsWith('image/')) {
        toast('请上传有效的图片文件');
        return;
      }
      
      // 检查文件大小是否超过20MB
      if (file.size > 20 * 1024 * 1024) {
        toast('图片文件大小不能超过20MB');
        return;
      }
      
      // 创建图片预览并保存
      const reader = new FileReader();
      reader.onloadend = () => {
        handleChange(section, field, reader.result as string);
        toast('图片上传成功');
      };
      reader.readAsDataURL(file);
    }
  };

  // 保存内容
  const saveContent = async () => {
    if (isSubmitting) return;
    
    setIsSubmitting(true);
    
    try {
      // 模拟API请求延迟
      await new Promise(resolve => setTimeout(resolve, 800));
      
      // 保存到localStorage
      localStorage.setItem('siteContent', JSON.stringify(content));
      
      // 更新页面标题
      document.title = content.siteInfo.title;
      
      // 显示成功消息
      setShowSuccessMessage(true);
      
      // 3秒后隐藏成功消息
      setTimeout(() => {
        setShowSuccessMessage(false);
      }, 3000);
      
      toast('内容保存成功！');
      
    } catch (error) {
      console.error('保存失败:', error);
      toast('保存失败，请重试');
    } finally {
      setIsSubmitting(false);
    }
  };

  // 重置为默认内容
  const resetToDefault = () => {
    if (window.confirm('确定要重置为默认内容吗？这将丢失所有自定义修改。')) {
      setContent(defaultContent);
      toast('已重置为默认内容，请点击保存以应用更改');
    }
  };

  // 渲染表单字段
  const renderFormField = (
    section: keyof SiteContent, 
    field: string, 
    label: string, 
    type: 'text' | 'textarea' | 'image' = 'text',
    rows: number = 4
  ) => {
    const value = (content[section] as any)[field] || '';
    
    if (type === 'image') {
      return (
        <div className="space-y-2">
          <label className={`block text-sm font-medium ${isDark ? 'text-gray-300' : 'text-gray-700'}`}>
            {label}
          </label>
          <div className="flex flex-col md:flex-row gap-6">
            <div className="w-full md:w-1/3">
              <div className="aspect-square rounded-lg overflow-hidden border-2 border-dashed border-gray-300 dark:border-gray-700">
                {value ? (
                  <img 
                    src={value} 
                    alt={label} 
                    className="w-full h-full object-cover" 
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-gray-400">
                    <Image size={32} />
                  </div>
                )}
              </div>
            </div>
            <div className="w-full md:w-2/3 flex items-center">
              <input
                type="file"
                accept="image/*"
                onChange={(e) => handleImageUpload(section, field, e)}
                className={`w-full px-4 py-3 rounded-lg ${
                  isDark 
                    ? 'bg-gray-800 border border-gray-700 text-white' 
                    : 'bg-white border border-gray-300 text-gray-900'
                }`}
              />
            </div>
          </div>
        </div>
      );
    }
    
    if (type === 'textarea') {
      return (
        <div className="space-y-2">
          <label className={`block text-sm font-medium ${isDark ? 'text-gray-300' : 'text-gray-700'}`}>
            {label}
          </label>
          <textarea
            value={value}
            onChange={(e) => handleChange(section, field, e.target.value)}
            rows={rows}
            className={`w-full px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all ${
              isDark 
                ? 'bg-gray-800 border border-gray-700 text-white' 
                : 'bg-white border border-gray-300 text-gray-900'
            }`}
          />
        </div>
      );
    }
    
    return (
      <div className="space-y-2">
        <label className={`block text-sm font-medium ${isDark ? 'text-gray-300' : 'text-gray-700'}`}>
          {label}
        </label>
        <input
          type="text"
          value={value}
          onChange={(e) => handleChange(section, field, e.target.value)}
          className={`w-full px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all ${
            isDark 
              ? 'bg-gray-800 border border-gray-700 text-white' 
              : 'bg-white border border-gray-300 text-gray-900'
          }`}
        />
      </div>
    );
  };

  // 渲染数组字段
  const renderArrayField = (
    section: keyof SiteContent, 
    field: string, 
    label: string
  ) => {
    const array = (content[section] as any)[field] || [];
    
    return (
      <div className="space-y-3">
        <label className={`block text-sm font-medium ${isDark ? 'text-gray-300' : 'text-gray-700'}`}>
          {label}
        </label>
        <div className="space-y-2">
          {array.map((item: string, index: number) => (
            <div key={index} className="flex items-center gap-2">
              <input
                type="text"
                value={item}
                onChange={(e) => handleArrayChange(section, field, index, e.target.value)}
                className={`flex-1 px-4 py-2 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all ${
                  isDark 
                    ? 'bg-gray-800 border border-gray-700 text-white' 
                    : 'bg-white border border-gray-300 text-gray-900'
                }`}
              />
              <button
                type="button"
                onClick={() => removeArrayItem(section, field, index)}
                disabled={array.length <= 1}
                className={`p-2 rounded-full ${
                  array.length <= 1 
                    ? 'text-gray-400 cursor-not-allowed' 
                    : isDark 
                      ? 'text-gray-400 hover:text-white hover:bg-gray-800' 
                      : 'text-gray-500 hover:text-gray-900 hover:bg-gray-100'
                } transition-colors`}
              >
                <X size={18} />
              </button>
            </div>
          ))}
        </div>
        <button
          type="button"
          onClick={() => addArrayItem(section, field)}
          className={`flex items-center gap-2 px-4 py-2 text-sm rounded-lg ${
            isDark 
              ? 'bg-gray-800 hover:bg-gray-700 text-gray-300' 
              : 'bg-gray-100 hover:bg-gray-200 text-gray-700'
          } transition-colors`}
        >
          <Edit size={16} />
          添加{label}
        </button>
      </div>
    );
  };

  // 渲染内容预览
  const renderPreview = () => {
    return (
      <div className={`p-6 rounded-lg ${isDark ? 'bg-gray-800' : 'bg-gray-50'} mt-8`}>
        <h3 className="text-lg font-semibold mb-4">内容预览</h3>
         {activeTab === 'hero' && (
           <div className={`p-6 rounded-lg shadow relative overflow-hidden`} style={{ minHeight: '300px' }}>
             {content.heroSection.backgroundImage && (
               <div 
                 className="absolute inset-0 z-0 bg-cover bg-center"
                 style={{ 
                   backgroundImage: `url(${content.heroSection.backgroundImage})`,
                   filter: 'brightness(0.7)'
                 }}
               />
             )}
             <div className="absolute inset-0 z-10 bg-gradient-to-r from-black/70 to-black/40 md:from-black/50 md:to-black/20" />
             <div className="relative z-20 text-white">
               <h1 className="text-2xl font-bold mb-4">{content.heroSection.heading}</h1>
               <p className={`mb-6 text-gray-200`}>{content.heroSection.subheading}</p>
               <button className="px-6 py-2 bg-indigo-500 text-white rounded-md">{content.heroSection.buttonText}</button>
             </div>
           </div>
         )}
        
        {activeTab === 'about' && (
          <div className={`p-6 rounded-lg ${isDark ? 'bg-gray-900' : 'bg-white'} shadow`}>
            <h2 className="text-xl font-bold mb-2">{content.aboutSection.title}</h2>
            <p className={`mb-4 text-sm ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>{content.aboutSection.subtitle}</p>
            <div className="flex items-center gap-4 mb-4">
              {content.aboutSection.imageUrl && (
                <div className="w-20 h-20 rounded-lg overflow-hidden">
                  <img src={content.aboutSection.imageUrl} alt={content.aboutSection.designerName} className="w-full h-full object-cover" />
                </div>
              )}
              <div>
                <h3 className="font-bold">{content.aboutSection.designerName}</h3>
                <p className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>{content.aboutSection.experience}年设计经验</p>
              </div>
            </div>
            <p className={`mb-4 ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>{content.aboutSection.bio1}</p>
            <p className={`mb-4 ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>{content.aboutSection.bio2}</p>
          </div>
        )}
        
        {activeTab === 'contact' && (
          <div className={`p-6 rounded-lg ${isDark ? 'bg-gray-900' : 'bg-white'} shadow`}>
            <h2 className="text-xl font-bold mb-2">{content.contactSection.title}</h2>
            <p className={`mb-4 text-sm ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>{content.contactSection.subtitle}</p>
            <div className="space-y-3">
              <div>
                <h3 className="text-sm font-medium">电话</h3>
                <p>{content.contactSection.phone}</p>
              </div>
              <div>
                <h3 className="text-sm font-medium">微信</h3>
                <p>{content.contactSection.wechat}</p>
              </div>
              <div>
                <h3 className="text-sm font-medium">邮箱</h3>
                <p>{content.contactSection.email}</p>
              </div>
              <p className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>{content.contactSection.responseTimeText}</p>
            </div>
          </div>
        )}
        
        {activeTab === 'site' && (
          <div className={`p-6 rounded-lg ${isDark ? 'bg-gray-900' : 'bg-white'} shadow`}>
            <h2 className="text-xl font-bold mb-2">网站基本信息</h2>
            <div className="space-y-3">
              <div>
                <h3 className="text-sm font-medium">网站标题</h3>
                <p>{content.siteInfo.title}</p>
              </div>
              <div>
                <h3 className="text-sm font-medium">网站描述</h3>
                <p>{content.siteInfo.description}</p>
              </div>
            </div>
          </div>
        )}
        
        {activeTab === 'footer' && (
          <div className={`p-6 rounded-lg ${isDark ? 'bg-gray-900' : 'bg-white'} shadow`}>
            <h2 className="text-xl font-bold mb-2">页脚内容</h2>
            <div className="space-y-3">
              <div>
                <h3 className="text-sm font-medium">版权信息</h3>
                <p>{content.footerSection.copyrightText}</p>
              </div>
              <div>
                <h3 className="text-sm font-medium">页脚描述</h3>
                <p>{content.footerSection.footerDescription}</p>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  };

  return (
    <div className={`min-h-screen ${isDark ? 'bg-gray-950 text-white' : 'bg-gray-50 text-gray-900'} transition-colors duration-300`}>
      {/* 顶部导航 */}
      <motion.header
        className={`sticky top-0 z-40 w-full py-4 ${isDark ? 'bg-gray-900/90' : 'bg-white/90'} backdrop-blur-md shadow-sm`}
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="container mx-auto px-6 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Edit size={24} className="text-indigo-500" />
            <h1 className="text-xl font-bold">内容管理后台</h1>
          </div>
          
          <div className="flex gap-3">
              <motion.button
                onClick={() => navigate('/admin/content')}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors ${
                  isDark ? 'bg-gray-800 hover:bg-gray-700' : 'bg-gray-100 hover:bg-gray-200'
                }`}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Edit size={16} />
                内容管理
              </motion.button>
              
              <motion.button
                onClick={() => navigate('/admin/messages')}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors ${
                  isDark ? 'bg-gray-800 hover:bg-gray-700' : 'bg-gray-100 hover:bg-gray-200'
                }`}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Mail size={16} />
                查看留言
              </motion.button>
              
              <motion.button
                onClick={() => navigate('/')}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors ${
                  isDark ? 'bg-gray-800 hover:bg-gray-700' : 'bg-gray-100 hover:bg-gray-200'
                }`}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Home size={16} />
                返回首页
              </motion.button>
            
            <motion.button
              onClick={handleLogout}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors ${
                isDark ? 'bg-gray-800 hover:bg-gray-700' : 'bg-gray-100 hover:bg-gray-200'
              }`}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <LogOut size={16} />
              退出登录
            </motion.button>
          </div>
        </div>
      </motion.header>

      <main className="container mx-auto px-6 py-10 max-w-6xl">
        {/* 成功保存消息 */}
        <AnimatePresence>
          {showSuccessMessage && (
            <motion.div
              className="mb-6 p-4 rounded-lg bg-green-50 text-green-800 dark:bg-green-900/30 dark:text-green-400 flex items-center gap-3"
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
            >
              <div className="p-1.5 rounded-full bg-green-100 text-green-600 dark:bg-green-800/50 dark:text-green-400">
                <Check size={18} />
              </div>
              <p className="font-medium">内容保存成功！</p>
            </motion.div>
          )}
        </AnimatePresence>

        {/* 内容管理卡片 */}
        <motion.div
          className={`p-8 rounded-xl shadow-lg ${isDark ? 'bg-gray-900' : 'bg-white'} border ${isDark ? 'border-gray-800' : 'border-gray-100'}`}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2 rounded-full bg-indigo-100 text-indigo-600 dark:bg-indigo-900/30 dark:text-indigo-400">
              <Edit size={24} />
            </div>
            <h2 className="text-2xl font-bold">编辑网站内容</h2>
          </div>
          
          {/* 标签页导航 */}
          <div className="flex flex-wrap gap-2 mb-8 border-b border-gray-200 dark:border-gray-800 pb-2">
            {[
              { id: 'site', label: '网站信息' },
              { id: 'hero', label: '首页英雄区' },
              { id: 'about', label: '关于板块' },
              { id: 'contact', label: '联系信息' },
              { id: 'footer', label: '页脚内容' }
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-4 py-2 rounded-t-lg text-sm font-medium transition-colors ${
                  activeTab === tab.id 
                    ? 'text-indigo-500 border-b-2 border-indigo-500' 
                    : isDark 
                      ? 'text-gray-400 hover:text-gray-200' 
                      : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
          
          {/* 内容编辑表单 */}
          <div className="space-y-8">
            {/* 网站基本信息 */}
            {activeTab === 'site' && (
              <div className="space-y-6">
                {renderFormField('siteInfo', 'title', '网站标题', 'text')}
                {renderFormField('siteInfo', 'description', '网站描述', 'textarea')}
              </div>
            )}
            
             {/* 首页英雄区 */}
             {activeTab === 'hero' && (
               <div className="space-y-6">
                 {renderFormField('heroSection', 'heading', '主标题', 'textarea', 2)}
                 {renderFormField('heroSection', 'subheading', '副标题', 'textarea', 4)}
                 {renderFormField('heroSection', 'buttonText', '按钮文字', 'text')}
                 {renderFormField('heroSection', 'backgroundImage', '背景图片', 'image')}
               </div>
             )}
            
            {/* 关于板块 */}
            {activeTab === 'about' && (
              <div className="space-y-6">
                {renderFormField('aboutSection', 'title', '板块标题', 'text')}
                {renderFormField('aboutSection', 'subtitle', '板块副标题', 'text')}
                {renderFormField('aboutSection', 'designerName', '设计师姓名', 'text')}
                {renderFormField('aboutSection', 'bio1', '个人简介1', 'textarea', 4)}
                {renderFormField('aboutSection', 'bio2', '个人简介2', 'textarea', 4)}
                {renderFormField('aboutSection', 'experience', '设计经验年数', 'text')}
                {renderFormField('aboutSection', 'imageUrl', '设计师照片', 'image')}
                {renderArrayField('aboutSection', 'skills', '设计专长')}
                {renderArrayField('aboutSection', 'tools', '使用工具')}
              </div>
            )}
            
            {/* 联系信息 */}
            {activeTab === 'contact' && (
              <div className="space-y-6">
                {renderFormField('contactSection', 'title', '板块标题', 'text')}
                {renderFormField('contactSection', 'subtitle', '板块副标题', 'text')}
                {renderFormField('contactSection', 'phone', '联系电话', 'text')}
                {renderFormField('contactSection', 'wechat', '微信', 'text')}
                {renderFormField('contactSection', 'email', '邮箱', 'text')}
                {renderFormField('contactSection', 'responseTimeText', '回复时间提示', 'text')}
              </div>
            )}
            
            {/* 页脚内容 */}
            {activeTab === 'footer' && (
              <div className="space-y-6">
                {renderFormField('footerSection', 'copyrightText', '版权信息', 'text')}
                {renderFormField('footerSection', 'footerDescription', '页脚描述', 'text')}
              </div>
            )}
          </div>
          
          {/* 操作按钮 */}
          <div className="flex flex-wrap gap-4 mt-10">
            <motion.button
              onClick={saveContent}
              className="px-8 py-3 bg-indigo-500 text-white rounded-lg font-medium hover:bg-indigo-600 transition-colors flex items-center gap-2"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              disabled={isSubmitting}
            >
              {isSubmitting ? (
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              ) : (
                <Check size={18} />
              )}
              保存更改
            </motion.button>
            
            <motion.button
              onClick={resetToDefault}
              className={`px-6 py-3 rounded-lg font-medium transition-colors flex items-center gap-2 ${
                isDark 
                  ? 'bg-gray-800 hover:bg-gray-700 text-gray-300' 
                  : 'bg-gray-200 hover:bg-gray-300 text-gray-700'
              }`}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <ArrowLeft size={18} />
              重置为默认值
            </motion.button>
          </div>
          
          {/* 内容预览 */}
          {renderPreview()}
        </motion.div>
      </main>
    </div>
  );
};

export default AdminContent;
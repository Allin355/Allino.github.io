import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Lock, Eye, EyeOff } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { useAuth } from '@/contexts/authContext.tsx';
import { useTheme } from '@/hooks/useTheme';

// 管理员登录页面
const AdminLogin: React.FC = () => {
  const navigate = useNavigate();
  const { setIsAuthenticated } = useAuth();
  const { isDark } = useTheme();
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // 简单的密码验证（实际项目中应该更复杂）
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (isSubmitting) return;
    
    setIsSubmitting(true);
    
    // 模拟API请求延迟
    setTimeout(() => {
      // 这里使用简单的密码验证，实际项目中应该使用更安全的方法
      if (password === 'admin123') { // 模拟密码，实际项目中应使用加密存储
        setIsAuthenticated(true);
        toast('登录成功！');
        
         // 检查是否有重定向路径
         const redirectPath = localStorage.getItem('redirectPath');
         if (redirectPath) {
           localStorage.removeItem('redirectPath');
           navigate(redirectPath);
         } else {
           navigate('/admin/content');
        }
      } else {
        toast('密码错误，请重试');
      }
      setIsSubmitting(false);
    }, 800);
  };

  return (
    <div className={`min-h-screen flex items-center justify-center p-4 ${isDark ? 'bg-gray-950 text-white' : 'bg-white text-gray-900'} transition-colors duration-300`}>
      <motion.div
        className={`w-full max-w-md p-8 rounded-xl shadow-lg ${isDark ? 'bg-gray-900' : 'bg-white'} border ${isDark ? 'border-gray-800' : 'border-gray-100'}`}
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="text-center mb-8">
          <motion.div
            className="inline-block p-3 rounded-full bg-indigo-500 text-white mb-4"
            whileHover={{ rotate: 10, scale: 1.1 }}
            transition={{ type: "spring", stiffness: 400, damping: 10 }}
          >
            <Lock size={28} />
          </motion.div>
          <h2 className="text-2xl font-bold">管理员登录</h2>
          <p className={`mt-2 ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>请输入密码以访问后台管理</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <label 
              htmlFor="password" 
              className={`block text-sm font-medium ${isDark ? 'text-gray-300' : 'text-gray-700'}`}
            >
              管理员密码
            </label>
            <div className="relative">
              <input
                type={showPassword ? "text" : "password"}
                id="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="请输入密码"
                className={`w-full px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all ${
                  isDark 
                    ? 'bg-gray-800 border border-gray-700 text-white placeholder-gray-500' 
                    : 'bg-gray-50 border border-gray-200 text-gray-900 placeholder-gray-400'
                }`}
                required
                autoFocus
              />
              <button
                type="button"
                className={`absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300`}
                onClick={() => setShowPassword(!showPassword)}
              >
                {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
              </button>
            </div>
          </div>

          <motion.button
            type="submit"
            className="w-full px-6 py-3 bg-indigo-500 text-white rounded-lg font-medium hover:bg-indigo-600 transition-colors flex items-center justify-center gap-2"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            disabled={isSubmitting}
          >
            {isSubmitting ? (
              <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
            ) : null}
            登录
          </motion.button>
        </form>

     <div className={`mt-6 text-center text-sm ${isDark ? 'text-gray-500' : 'text-gray-400'}`}>
      <p>生产环境提示：后台登录密码为 admin123（演示用）</p>
    </div>
      </motion.div>
    </div>
  );
};

export default AdminLogin;
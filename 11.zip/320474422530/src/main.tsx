import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import { Toaster } from 'sonner';
import App from "./App.tsx";
import "./index.css";

// 设置Toaster默认配置
const toasterConfig = {
  position: 'top-right' as const,
  duration: 3000,
  closeButton: true,
  // 生产环境优化：根据主题自动调整样式
  style: {
    backgroundColor: 'rgba(255, 255, 255, 0.95)',
    borderRadius: '8px',
    boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)',
    border: 'none',
    color: '#1f2937',
  },
  // 生产环境禁用开发模式
  richColors: true,
  toastOptions: {
    success: {
      duration: 3000,
    },
    error: {
      duration: 5000,
    }
  }
};

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <BrowserRouter>
      <App />
      <Toaster {...toasterConfig} />
    </BrowserRouter>
  </StrictMode>
);

import React, { ReactNode } from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '@/contexts/authContext.tsx';

interface ProtectedRouteProps {
  children: ReactNode;
}

// 受保护的路由组件，确保只有认证用户才能访问
const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ children }) => {
  const { isAuthenticated } = useAuth();

  // 如果未认证，重定向到登录页面
  if (!isAuthenticated) {
    // 保存当前路径，登录后可以重定向回来
    const currentPath = window.location.pathname;
    localStorage.setItem('redirectPath', currentPath);
    return <Navigate to="/admin/login" replace />;
  }

  // 如果已认证，渲染子组件
  return <>{children}</>;
};

export default ProtectedRoute;
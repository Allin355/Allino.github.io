import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Upload, Image, Check, Plus, X, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';
import { useTheme } from '@/hooks/useTheme';

// 定义上传表单的Props类型
interface UploadFormProps {
  onSubmit: (data: FormData) => void;
  isSubmitting: boolean;
}

// 上传表单组件
const UploadForm: React.FC<UploadFormProps> = ({ onSubmit, isSubmitting }) => {
  const { isDark } = useTheme();
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState('web');
  const [description, setDescription] = useState('');
  const [image, setImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState('');
  const [client, setClient] = useState('');
  const [date, setDate] = useState(new Date().toLocaleDateString('zh-CN', { year: 'numeric', month: 'long' }));
  const [tools, setTools] = useState('');

  // 处理图片上传预览
  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      
      // 检查文件类型是否为图片
      if (!file.type.startsWith('image/')) {
        toast('请上传有效的图片文件');
        return;
      }
      
       // 检查文件大小是否超过20MB
      if (file.size > 20 * 1024 * 1024) {
        toast('图片文件大小不能超过20MB');
        return;
      }
      
      setImage(file);
      
      // 创建图片预览
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  // 处理表单提交
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // 表单验证
    if (!title.trim()) {
      toast('请输入作品标题');
      return;
    }
    
    if (!image) {
      toast('请上传作品图片');
      return;
    }
    
    if (!description.trim()) {
      toast('请输入作品描述');
      return;
    }
    
    // 创建FormData对象
    const formData = new FormData();
    formData.append('title', title);
    formData.append('category', category);
    formData.append('description', description);
    formData.append('image', image);
    formData.append('client', client);
    formData.append('date', date);
    formData.append('tools', tools);
    
    // 调用父组件传递的提交函数
    onSubmit(formData);
  };

  // 移除图片预览
  const removeImage = () => {
    setImage(null);
    setImagePreview('');
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-8">
      {/* 作品标题 */}
      <div className="space-y-2">
        <label 
          htmlFor="title" 
          className={`block text-sm font-medium ${isDark ? 'text-gray-300' : 'text-gray-700'}`}
        >
          作品标题 <span className="text-red-500">*</span>
        </label>
        <input
          type="text"
          id="title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="请输入作品标题"
          className={`w-full px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all ${
            isDark 
              ? 'bg-gray-800 border border-gray-700 text-white placeholder-gray-500' 
              : 'bg-white border border-gray-300 text-gray-900 placeholder-gray-400'
          }`}
          required
        />
      </div>

      {/* 作品分类 */}
      <div className="space-y-2">
        <label 
          htmlFor="category" 
          className={`block text-sm font-medium ${isDark ? 'text-gray-300' : 'text-gray-700'}`}
        >
          作品分类 <span className="text-red-500">*</span>
        </label>
        <select
          id="category"
          value={category}
          onChange={(e) => setCategory(e.target.value)}
          className={`w-full px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all ${
            isDark 
              ? 'bg-gray-800 border border-gray-700 text-white' 
              : 'bg-white border border-gray-300 text-gray-900'
          }`}
          required
        >
          <option value="web">网页设计</option>
          <option value="graphic">平面设计</option>
          <option value="branding">品牌设计</option>
          <option value="ui">UI设计</option>
        </select>
      </div>

      {/* 作品图片上传 */}
      <div className="space-y-2">
        <label 
          htmlFor="image" 
          className={`block text-sm font-medium ${isDark ? 'text-gray-300' : 'text-gray-700'}`}
        >
          作品图片 <span className="text-red-500">*</span> (最大20MB)
        </label>
        
        {imagePreview ? (
          <motion.div 
            className="relative rounded-lg overflow-hidden border-2 border-dashed border-indigo-500 cursor-pointer"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3 }}
          >
            <img 
              src={imagePreview} 
              alt="预览图" 
              className="w-full h-auto object-cover" 
              style={{ maxHeight: '400px' }}
            />
            <button 
              type="button"
              onClick={removeImage}
              className="absolute top-3 right-3 p-2 rounded-full bg-white/80 text-gray-800 hover:bg-white transition-colors"
            >
              <X size={18} />
            </button>
          </motion.div>
        ) : (
          <motion.label
            htmlFor="image"
            className={`flex flex-col items-center justify-center w-full h-64 border-2 border-dashed rounded-lg cursor-pointer ${
              isDark 
                ? 'border-gray-700 hover:border-indigo-500 bg-gray-800/50' 
                : 'border-gray-300 hover:border-indigo-500 bg-gray-50'
            } transition-colors`}
            whileHover={{ scale: 1.01 }}
            whileTap={{ scale: 0.99 }}
          >
            <div className="flex flex-col items-center justify-center pt-5 pb-6">
              <Upload size={32} className="text-indigo-500 mb-2" />
              <p className={`mb-2 text-sm ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>
                <span className="font-medium text-indigo-500">点击上传</span> 或拖放图片
              </p>
              <p className={`text-xs ${isDark ? 'text-gray-500' : 'text-gray-400'}`}>
                PNG, JPG, JPEG (最大 20MB)
              </p>
            </div>
            <input
              id="image"
              type="file"
              accept="image/*"
              onChange={handleImageChange}
              className="hidden"
              required
            />
          </motion.label>
        )}
      </div>

      {/* 作品描述 */}
      <div className="space-y-2">
        <label 
          htmlFor="description" 
          className={`block text-sm font-medium ${isDark ? 'text-gray-300' : 'text-gray-700'}`}
        >
          作品描述 <span className="text-red-500">*</span>
        </label>
        <textarea
          id="description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          placeholder="请详细描述作品的设计理念、实现过程等"
          rows={5}
          className={`w-full px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all ${
            isDark 
              ? 'bg-gray-800 border border-gray-700 text-white placeholder-gray-500' 
              : 'bg-white border border-gray-300 text-gray-900 placeholder-gray-400'
          }`}
          required
        ></textarea>
      </div>

      {/* 项目客户 */}
      <div className="space-y-2">
        <label 
          htmlFor="client" 
          className={`block text-sm font-medium ${isDark ? 'text-gray-300' : 'text-gray-700'}`}
        >
          客户
        </label>
        <input
          type="text"
          id="client"
          value={client}
          onChange={(e) => setClient(e.target.value)}
          placeholder="请输入客户名称（选填）"
          className={`w-full px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all ${
            isDark 
              ? 'bg-gray-800 border border-gray-700 text-white placeholder-gray-500' 
              : 'bg-white border border-gray-300 text-gray-900 placeholder-gray-400'
          }`}
        />
      </div>

      {/* 项目日期 */}
      <div className="space-y-2">
        <label 
          htmlFor="date" 
          className={`block text-sm font-medium ${isDark ? 'text-gray-300' : 'text-gray-700'}`}
        >
          完成日期
        </label>
        <input
          type="text"
          id="date"
          value={date}
          onChange={(e) => setDate(e.target.value)}
          placeholder="请输入项目完成日期（如：2023年10月，选填）"
          className={`w-full px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all ${
            isDark 
              ? 'bg-gray-800 border border-gray-700 text-white placeholder-gray-500' 
              : 'bg-white border border-gray-300 text-gray-900 placeholder-gray-400'
          }`}
        />
      </div>

      {/* 工具使用 */}
      <div className="space-y-2">
        <label 
          htmlFor="tools" 
          className={`block text-sm font-medium ${isDark ? 'text-gray-300' : 'text-gray-700'}`}
        >
          使用工具
        </label>
        <input
          type="text"
          id="tools"
          value={tools}
          onChange={(e) => setTools(e.target.value)}
          placeholder="请输入使用的设计工具，用逗号分隔（如：Figma, Adobe Illustrator，选填）"
          className={`w-full px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all ${
            isDark 
              ? 'bg-gray-800 border border-gray-700 text-white placeholder-gray-500' 
              : 'bg-white border border-gray-300 text-gray-900 placeholder-gray-400'
          }`}
        />
      </div>

      {/* 提交按钮 */}
      <motion.button
        type="submit"
        className="w-full px-6 py-3 bg-indigo-500 text-white rounded-lg font-medium hover:bg-indigo-600 transition-colors flex items-center justify-center gap-2"
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        disabled={isSubmitting}
      >
        {isSubmitting ? (
          <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
        ) : (
          <Check size={18} />
        )}
        上传作品
      </motion.button>
    </form>
  );
};

export default UploadForm;